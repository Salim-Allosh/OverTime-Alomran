# دليل البدء السريع - رفع التطبيق على GoDaddy

## ⚡ خطوات سريعة (5 دقائق)

### 1️⃣ فك الضغط
- فك ضغط `OverTime_Deployment.zip`
- ستحصل على المجلدات بنفس الهيكل المطلوب

### 2️⃣ رفع الملفات

**Backend:**
- ارفع محتويات `backend-api/` → `public_html/backend-api/`

**Frontend:**
- ارفع `index.html` → `public_html/index.html` (في الجذر مباشرة)
- ارفع `assets/` → `public_html/assets/` (في الجذر مباشرة)

### 3️⃣ إعداد قاعدة البيانات
- أنشئ قاعدة بيانات MySQL في cPanel
- سجل البيانات (host, user, password, name)

### 4️⃣ إعداد Backend
- أنشئ `.env` في `backend-api/` (انسخ من `env.example`)
- عدّل بيانات قاعدة البيانات في `.env`
- عدّل `.htaccess` (استبدل `YOUR_USERNAME`)

### 5️⃣ تعديل رابط API
- افتح `assets/index-*.js` (أكبر ملف)
- ابحث عن `http://localhost:8000`
- استبدله بـ `https://yourdomain.com/backend-api`

### 6️⃣ تثبيت المتطلبات
```bash
cd public_html/backend-api
pip3 install -r requirements.txt
```

### 7️⃣ إنشاء الجداول
- استورد SQL أو أنشئ الجداول يدوياً

### 8️⃣ اختبار
- افتح `https://yourdomain.com/backend-api/docs` (API)
- افتح `https://yourdomain.com/` (Frontend)

---

## 📋 الهيكل النهائي على السيرفر

```
public_html/
├── index.html          ← Frontend
├── assets/             ← Frontend assets
│   ├── index-*.js
│   └── index-*.css
└── backend-api/
    ├── src/
    │   └── main.py
    ├── wsgi.py
    ├── .htaccess
    ├── .env
    └── requirements.txt
```

---

## ⚠️ ملاحظات مهمة

1. **Frontend في الجذر:** `index.html` يجب أن يكون في `public_html/` مباشرة
2. **لا ترفع `.env` علناً:** يحتوي على بيانات حساسة
3. **Python 3.8+:** تأكد من الإصدار الصحيح

---

**راجع `README_DEPLOYMENT.md` للتفاصيل الكاملة**
