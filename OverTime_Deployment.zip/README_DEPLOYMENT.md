# تعليمات رفع التطبيق على GoDaddy

## 📦 هيكل الملفات (جاهز للرفع مباشرة)

هذا الملف المضغوط يحتوي على الملفات بنفس الهيكل المطلوب على السيرفر:

```
backend-api/
  ├── src/
  │   ├── main.py          # API الرئيسي
  │   └── __init__.py
  ├── wsgi.py              # نقطة الدخول لـ WSGI
  ├── .htaccess            # إعدادات Apache (يحتاج تعديل)
  ├── requirements.txt     # متطلبات Python
  ├── env.example          # مثال لملف البيئة
  └── __init__.py

index.html                 ← Frontend (في الجذر مباشرة)
assets/                    ← Frontend assets (في الجذر مباشرة)
  ├── index-*.js
  └── index-*.css
```

## 🚀 خطوات الرفع السريعة

### 1. فك الضغط
- قم بفك ضغط الملف `OverTime_Deployment.zip`
- ستجد المجلدات والملفات بنفس الهيكل المطلوب

### 2. رفع الملفات إلى GoDaddy

#### Backend:
1. اختر **جميع** محتويات مجلد `backend-api/`
2. ارفعها إلى `public_html/backend-api/` على السيرفر
3. تأكد من أن الهيكل يكون: `public_html/backend-api/src/main.py`

#### Frontend:
1. اختر ملف `index.html` (في الجذر)
2. اختر مجلد `assets/` (في الجذر)
3. ارفعهم إلى `public_html/` مباشرة (الجذر)
4. تأكد من أن الهيكل يكون: `public_html/index.html` و `public_html/assets/`

**الهيكل النهائي على السيرفر:**
```
public_html/
├── index.html              ← هنا
├── assets/                 ← هنا
│   ├── index-*.js
│   └── index-*.css
└── backend-api/
    ├── src/
    │   └── main.py
    ├── wsgi.py
    ├── .htaccess
    └── ...
```

### 3. إعداد قاعدة البيانات MySQL

1. في cPanel، أنشئ قاعدة بيانات MySQL جديدة
2. سجل بيانات الاتصال:
   - `DB_HOST`: عادة `localhost`
   - `DB_USER`: اسم المستخدم
   - `DB_PASSWORD`: كلمة المرور
   - `DB_NAME`: اسم قاعدة البيانات
   - `DB_PORT`: عادة `3306`

### 4. إعداد متغيرات البيئة

1. في مجلد `backend-api/` على السيرفر، أنشئ ملف `.env`
2. انسخ محتوى `env.example` إلى `.env`
3. عدّل القيم:

```env
DB_HOST=localhost
DB_USER=your_database_user
DB_PASSWORD=your_database_password
DB_NAME=your_database_name
DB_PORT=3306
ALLOWED_ORIGINS=https://yourdomain.com,https://www.yourdomain.com
```

### 5. تعديل ملف .htaccess

1. افتح `backend-api/.htaccess` على السيرفر
2. استبدل `YOUR_USERNAME` باسم المستخدم الفعلي:

```apache
SetEnv PYTHONPATH "/home/YOUR_USERNAME/public_html/backend-api:/home/YOUR_USERNAME/public_html/backend-api/src"
SetEnv WORKING_DIR "/home/YOUR_USERNAME/public_html/backend-api"
```

**كيف تعرف اسم المستخدم؟**
- عادة يكون في مسار `public_html` نفسه
- أو راجع معلومات الحساب في cPanel

### 6. تعديل رابط API في Frontend

1. افتح ملف `assets/index-*.js` (أكبر ملف، مثل `index-BhyRosgM.js`)
2. ابحث عن `http://localhost:8000`
3. استبدله برابط Backend الفعلي:
   - إذا كان Backend على نفس الدومين: `https://yourdomain.com/backend-api`
   - إذا كان على دومين فرعي: `https://api.yourdomain.com`

**مثال للبحث والاستبدال:**
```
ابحث عن: http://localhost:8000
استبدله بـ: https://yourdomain.com/backend-api
```

### 7. تثبيت متطلبات Python

1. في cPanel، افتح "Terminal" أو "SSH Access"
2. انتقل إلى مجلد backend-api:
   ```bash
   cd public_html/backend-api
   ```
3. قم بتثبيت المتطلبات:
   ```bash
   pip3 install -r requirements.txt
   ```

**ملاحظة:** قد تحتاج لاستخدام `pip3` أو `python3 -m pip` حسب إعدادات GoDaddy.

### 8. إنشاء جداول قاعدة البيانات

1. استورد ملف SQL لإنشاء الجداول (إن وجد)
2. أو أنشئ الجداول يدوياً من خلال phpMyAdmin

### 9. إعداد Python في GoDaddy

1. تأكد من تفعيل Python في cPanel
2. تأكد من أن Python 3.8+ مثبت
3. قد تحتاج لتحديث إعدادات `.htaccess` لدعم Python

### 10. اختبار التطبيق

1. افتح `https://yourdomain.com/backend-api/docs` للتحقق من API
2. افتح `https://yourdomain.com/` للتحقق من Frontend

---

## 🔧 حل المشاكل الشائعة

### خطأ 500 Internal Server Error
- ✅ تحقق من ملف `.env` وتأكد من صحة بيانات قاعدة البيانات
- ✅ تحقق من ملف `.htaccess` وتأكد من صحة المسارات
- ✅ تحقق من سجلات الأخطاء في cPanel (Error Logs)

### CORS Error
- ✅ تأكد من تحديث `ALLOWED_ORIGINS` في ملف `.env`
- ✅ تأكد من تحديث رابط API في ملفات JavaScript

### Database Connection Error
- ✅ تحقق من صحة بيانات الاتصال بقاعدة البيانات
- ✅ تأكد من أن قاعدة البيانات موجودة
- ✅ تأكد من أن المستخدم لديه صلاحيات الوصول

### Python Module Not Found
- ✅ تأكد من تثبيت جميع المتطلبات: `pip3 install -r requirements.txt`
- ✅ قد تحتاج لاستخدام Virtual Environment

### الملفات لا تُحمل (404)
- ✅ تأكد من أن `index.html` في `public_html/` مباشرة (وليس في مجلد فرعي)
- ✅ تأكد من أن `assets/` في `public_html/assets/` مباشرة
- ✅ تحقق من صلاحيات الملفات (chmod 644 للملفات، chmod 755 للمجلدات)

---

## 📝 ملاحظات مهمة

1. **الأمان:**
   - ⚠️ **لا ترفع** ملف `.env` علناً (يحتوي على بيانات حساسة)
   - ⚠️ تأكد من أن ملف `.env` غير قابل للوصول من المتصفح

2. **الصلاحيات:**
   - ملفات Python: `chmod 644` أو `755`
   - المجلدات: `chmod 755`
   - ملف `.htaccess`: `chmod 644`

3. **Python Version:**
   - تأكد من استخدام Python 3.8 أو أحدث
   - راجع إعدادات Python في cPanel

4. **Dependencies:**
   - قد تحتاج لتثبيت بعض المكتبات يدوياً حسب إعدادات GoDaddy
   - راجع `requirements.txt` للحصول على قائمة المتطلبات

---

## 🔗 روابط مفيدة

- FastAPI Documentation: https://fastapi.tiangolo.com/
- GoDaddy Python Hosting Guide: راجع دليل GoDaddy
- Vite Build Documentation: https://vitejs.dev/guide/build.html

---

## ✅ قائمة التحقق (Checklist)

- [ ] تم فك ضغط الملف
- [ ] تم رفع ملفات Backend إلى `public_html/backend-api/`
- [ ] تم رفع `index.html` إلى `public_html/`
- [ ] تم رفع `assets/` إلى `public_html/assets/`
- [ ] تم إنشاء قاعدة البيانات MySQL
- [ ] تم إنشاء ملف `.env` وتعديله
- [ ] تم تعديل `.htaccess` ببيانات المستخدم الصحيحة
- [ ] تم تعديل رابط API في ملفات JavaScript
- [ ] تم تثبيت متطلبات Python
- [ ] تم إنشاء جداول قاعدة البيانات
- [ ] تم تفعيل Python في cPanel
- [ ] تم اختبار API (`/backend-api/docs`)
- [ ] تم اختبار Frontend (`/`)

---

**بالتوفيق! 🚀**
