"""
FastAPI implementation for session management.
No seed data; relies entirely on DB state.
"""
from datetime import datetime, date, timedelta
from calendar import month_name
from decimal import Decimal
from typing import List, Optional
import random

from fastapi import Depends, FastAPI, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from passlib.context import CryptContext
from pydantic import BaseModel, condecimal, Field
from sqlalchemy import (
    Column,
    Integer,
    String,
    Date,
    DateTime,
    DECIMAL,
    ForeignKey,
    Boolean,
    Text,
    create_engine,
    func,
    case,
    or_,
    and_,
)
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import Session, relationship, sessionmaker, joinedload
import os
from pathlib import Path
import logging

# Configure logging for debugging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# MySQL Database Configuration
# Use environment variables for database connection (for production flexibility)
DB_HOST = os.getenv("DB_HOST", "localhost")
DB_USER = os.getenv("DB_USER", "root")
DB_PASSWORD = os.getenv("DB_PASSWORD", "")
DB_NAME = os.getenv("DB_NAME", "AlomranReportsDB")
DB_PORT = os.getenv("DB_PORT", "3306")

# Construct MySQL connection URL
# Using pymysql driver (install: pip install pymysql)
# Alternative: mysql+mysqlconnector:// (requires mysql-connector-python)
DATABASE_URL = f"mysql+pymysql://{DB_USER}:{DB_PASSWORD}@{DB_HOST}:{DB_PORT}/{DB_NAME}?charset=utf8mb4"

logger.info(f"Database URL: mysql+pymysql://{DB_USER}:***@{DB_HOST}:{DB_PORT}/{DB_NAME}")
logger.info(f"Connecting to MySQL database: {DB_NAME}")

# Create engine with proper connection arguments for MySQL
try:
    engine = create_engine(
        DATABASE_URL,
        pool_pre_ping=True,  # Verify connections before using
        pool_recycle=3600,   # Recycle connections after 1 hour
        echo=False           # Set to True for SQL query logging
    )
    logger.info("Database engine created successfully")
except Exception as e:
    logger.error(f"Failed to create database engine: {e}")
    logger.error("Make sure MySQL is running and the database exists")
    raise
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="auth/login")
oauth2_scheme_optional = OAuth2PasswordBearer(tokenUrl="auth/login", auto_error=False)


# ---------- DB MODELS ----------
class Branch(Base):
    __tablename__ = "branches"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(255), nullable=False, unique=True)
    default_hourly_rate = Column(DECIMAL(10, 2), nullable=False, default=0)

    operation_accounts = relationship("OperationAccount", back_populates="branch")
    sales_staff = relationship("SalesStaff", back_populates="branch")


class OperationAccount(Base):
    __tablename__ = "operation_accounts"
    id = Column(Integer, primary_key=True, index=True)
    username = Column(String(100), unique=True, nullable=False)
    password_hash = Column(String(255), nullable=False)
    branch_id = Column(Integer, ForeignKey("branches.id"), nullable=False)
    is_super_admin = Column(Boolean, default=False)
    is_sales_manager = Column(Boolean, default=False)  # مدير مبيعات في الفرع
    is_operation_manager = Column(Boolean, default=False)  # مدير أوبريشن للفرع
    is_branch_account = Column(Boolean, default=False)  # حساب الفرع (عرض فقط)
    is_backdoor = Column(Boolean, default=False)  # حساب باكدور (مخفي)
    is_active = Column(Boolean, default=True)  # تفعيل/تعطيل الحساب

    branch = relationship("Branch", back_populates="operation_accounts")


class SessionDraft(Base):
    __tablename__ = "session_drafts"
    id = Column(Integer, primary_key=True, index=True)
    branch_id = Column(Integer, ForeignKey("branches.id"), nullable=False, index=True)
    teacher_name = Column(String(255), nullable=False)
    student_name = Column(String(255), nullable=False)
    session_date = Column(Date, nullable=False)
    start_time = Column(String(10), nullable=True)
    end_time = Column(String(10), nullable=True)
    duration_hours = Column(DECIMAL(5, 2), nullable=False)
    duration_text = Column(String(50), nullable=False)
    status = Column(String(50), nullable=False, default="pending")
    rejection_reason = Column(String(500), nullable=True)
    created_at = Column(DateTime, server_default=func.now(), nullable=False)


class SessionRecord(Base):
    __tablename__ = "sessions"
    id = Column(Integer, primary_key=True, index=True)
    branch_id = Column(Integer, ForeignKey("branches.id"), nullable=False, index=True)
    teacher_name = Column(String(255), nullable=False)
    student_name = Column(String(255), nullable=False)
    session_date = Column(Date, nullable=False)
    start_time = Column(String(10), nullable=True)
    end_time = Column(String(10), nullable=True)
    duration_hours = Column(DECIMAL(5, 2), nullable=False)
    duration_text = Column(String(50), nullable=False)
    contract_number = Column(String(100), nullable=False)
    hourly_rate = Column(DECIMAL(10, 2), nullable=False)
    calculated_amount = Column(DECIMAL(12, 2), nullable=False)
    location = Column(String(20), nullable=False, default="internal")  # internal or external
    approved_by = Column(Integer, ForeignKey("operation_accounts.id"), nullable=False)
    created_at = Column(DateTime, server_default=func.now(), nullable=False)


class Expense(Base):
    __tablename__ = "expenses"
    id = Column(Integer, primary_key=True, index=True)
    branch_id = Column(Integer, ForeignKey("branches.id"), nullable=False, index=True)
    teacher_name = Column(String(255), nullable=True)  # Optional teacher name
    title = Column(String(255), nullable=False)
    amount = Column(DECIMAL(12, 2), nullable=False)
    created_at = Column(DateTime, server_default=func.now(), nullable=False)


class Course(Base):
    __tablename__ = "courses"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(255), nullable=False, unique=True, index=True)
    type = Column(String(100), nullable=True)
    is_active = Column(Boolean, default=True, index=True)
    created_at = Column(DateTime, server_default=func.now(), nullable=False)
    updated_at = Column(DateTime, nullable=True, onupdate=func.now())


class PaymentMethod(Base):
    __tablename__ = "payment_methods"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(255), nullable=False, unique=True, index=True)
    discount_percentage = Column(DECIMAL(5, 4), nullable=False, default=0)
    is_active = Column(Boolean, default=True, index=True)
    created_at = Column(DateTime, server_default=func.now(), nullable=False)
    updated_at = Column(DateTime, nullable=True, onupdate=func.now())


class Contract(Base):
    __tablename__ = "contracts"
    id = Column(Integer, primary_key=True, index=True)
    contract_number = Column(String(100), unique=True, nullable=False, index=True)
    student_name = Column(String(255), nullable=False)
    client_phone = Column(String(20), nullable=True)
    registration_source = Column(String(255), nullable=True)
    branch_id = Column(Integer, ForeignKey("branches.id"), nullable=False, index=True)
    sales_staff_id = Column(Integer, ForeignKey("sales_staff.id"), nullable=True, index=True)
    course_id = Column(Integer, ForeignKey("courses.id"), nullable=True, index=True)
    total_amount = Column(DECIMAL(12, 2), nullable=True)
    payment_amount = Column(DECIMAL(12, 2), nullable=True)
    payment_method_id = Column(Integer, ForeignKey("payment_methods.id"), nullable=True, index=True)
    payment_number = Column(String(100), nullable=True)
    remaining_amount = Column(DECIMAL(12, 2), nullable=True)
    net_amount = Column(DECIMAL(12, 2), nullable=True)
    # حقول العقود المشتركة
    contract_type = Column(String(20), nullable=False, default="new", index=True)  # new, shared, old_payment
    shared_branch_id = Column(Integer, ForeignKey("branches.id"), nullable=True, index=True)  # الفرع المشترك
    shared_amount = Column(DECIMAL(12, 2), nullable=True)  # المبلغ المشترك
    parent_contract_id = Column(Integer, ForeignKey("contracts.id"), nullable=True, index=True)  # للعقود القديمة (الدفعات)
    contract_date = Column(Date, nullable=True, index=True)  # تاريخ العقد
    notes = Column(Text, nullable=True)
    created_at = Column(DateTime, server_default=func.now(), nullable=False)
    updated_at = Column(DateTime, nullable=True, onupdate=func.now())
    
    sales_staff = relationship("SalesStaff")
    course = relationship("Course")
    payment_method = relationship("PaymentMethod")
    shared_branch = relationship("Branch", foreign_keys=[shared_branch_id])
    parent_contract = relationship("Contract", remote_side=[id], foreign_keys=[parent_contract_id])
    payments = relationship("ContractPayment", back_populates="contract", cascade="all, delete-orphan")


class ContractPayment(Base):
    __tablename__ = "contract_payments"
    id = Column(Integer, primary_key=True, index=True)
    contract_id = Column(Integer, ForeignKey("contracts.id"), nullable=False, index=True)
    payment_amount = Column(DECIMAL(12, 2), nullable=False)
    payment_method_id = Column(Integer, ForeignKey("payment_methods.id"), nullable=True, index=True)
    payment_number = Column(String(100), nullable=True)
    net_amount = Column(DECIMAL(12, 2), nullable=True)  # الصافي لهذه الدفعة
    created_at = Column(DateTime, server_default=func.now(), nullable=False)
    
    contract = relationship("Contract", back_populates="payments")
    payment_method = relationship("PaymentMethod")


class DailyReport(Base):
    __tablename__ = "daily_reports"
    id = Column(Integer, primary_key=True, index=True)
    branch_id = Column(Integer, ForeignKey("branches.id"), nullable=False, index=True)
    report_date = Column(Date, nullable=False, index=True)
    total_sessions = Column(Integer, nullable=False, default=0)
    total_hours = Column(DECIMAL(10, 2), nullable=False, default=0)
    total_amount = Column(DECIMAL(12, 2), nullable=False, default=0)
    internal_sessions = Column(Integer, nullable=False, default=0)
    external_sessions = Column(Integer, nullable=False, default=0)
    internal_amount = Column(DECIMAL(12, 2), nullable=False, default=0)
    external_amount = Column(DECIMAL(12, 2), nullable=False, default=0)
    total_expenses = Column(DECIMAL(12, 2), nullable=False, default=0)
    net_profit = Column(DECIMAL(12, 2), nullable=False, default=0)
    notes = Column(String(1000), nullable=True)
    created_at = Column(DateTime, server_default=func.now(), nullable=False)
    updated_at = Column(DateTime, nullable=True, onupdate=func.now())


class SalesStaff(Base):
    __tablename__ = "sales_staff"
    id = Column(Integer, primary_key=True, index=True)
    branch_id = Column(Integer, ForeignKey("branches.id"), nullable=False, index=True)
    name = Column(String(255), nullable=False)
    phone = Column(String(20), nullable=True)
    email = Column(String(255), nullable=True)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, server_default=func.now(), nullable=False)

    branch = relationship("Branch", back_populates="sales_staff")


class DailySalesReport(Base):
    __tablename__ = "daily_sales_reports"
    id = Column(Integer, primary_key=True, index=True)
    branch_id = Column(Integer, ForeignKey("branches.id"), nullable=False, index=True)
    sales_staff_id = Column(Integer, ForeignKey("sales_staff.id"), nullable=False, index=True)
    report_date = Column(Date, nullable=False, index=True)
    sales_amount = Column(DECIMAL(12, 2), nullable=False)
    number_of_deals = Column(Integer, nullable=False, default=0)
    daily_calls = Column(Integer, nullable=False, default=0)
    hot_calls = Column(Integer, nullable=False, default=0)
    walk_ins = Column(Integer, nullable=False, default=0)
    branch_leads = Column(Integer, nullable=False, default=0)
    online_leads = Column(Integer, nullable=False, default=0)
    extra_leads = Column(Integer, nullable=False, default=0)
    number_of_visits = Column(Integer, nullable=False, default=0)
    notes = Column(String(1000), nullable=True)
    created_at = Column(DateTime, server_default=func.now(), nullable=False)

    branch = relationship("Branch")
    sales_staff = relationship("SalesStaff")
    visits = relationship("SalesVisit", back_populates="daily_sales_report", cascade="all, delete-orphan")


class SalesVisit(Base):
    __tablename__ = "sales_visits"
    id = Column(Integer, primary_key=True, index=True)
    daily_sales_report_id = Column(Integer, ForeignKey("daily_sales_reports.id"), nullable=False, index=True)
    branch_id = Column(Integer, ForeignKey("branches.id"), nullable=False, index=True)
    update_details = Column(Text, nullable=True)
    visit_order = Column(Integer, nullable=False, default=1)
    created_at = Column(DateTime, server_default=func.now(), nullable=False)

    daily_sales_report = relationship("DailySalesReport", back_populates="visits")
    branch = relationship("Branch")


# ---------- SCHEMAS ----------
class BranchIn(BaseModel):
    name: str
    default_hourly_rate: condecimal(max_digits=10, decimal_places=2)


class BranchOut(BranchIn):
    id: int

    class Config:
        from_attributes = True


class OperationAccountIn(BaseModel):
    username: str
    password: Optional[str] = Field(default=None, min_length=6)
    branch_id: int
    is_super_admin: bool = False
    is_sales_manager: bool = False  # مدير مبيعات في الفرع
    is_operation_manager: bool = False  # مدير أوبريشن للفرع
    is_branch_account: bool = False  # حساب الفرع (عرض فقط)
    is_backdoor: bool = False  # حساب باكدور (مخفي)
    is_active: bool = True  # تفعيل/تعطيل الحساب


class OperationAccountOut(BaseModel):
    id: int
    username: str
    branch_id: int
    is_super_admin: bool
    is_sales_manager: bool  # مدير مبيعات في الفرع
    is_operation_manager: bool  # مدير أوبريشن للفرع
    is_branch_account: bool  # حساب الفرع (عرض فقط)
    is_backdoor: bool  # حساب باكدور (مخفي)
    is_active: bool  # تفعيل/تعطيل الحساب

    class Config:
        from_attributes = True


class DraftCreate(BaseModel):
    teacher_name: str
    student_name: str
    session_date: date
    start_time: Optional[str] = None
    end_time: Optional[str] = None
    duration_hours: condecimal(max_digits=5, decimal_places=2)
    duration_text: str
    branch_id: int


class DraftOut(BaseModel):
    id: int
    branch_id: int
    teacher_name: str
    student_name: str
    session_date: date
    start_time: Optional[str]
    end_time: Optional[str]
    duration_hours: Decimal
    duration_text: str
    status: str
    rejection_reason: Optional[str]
    created_at: datetime

    class Config:
        from_attributes = True


class DraftApprove(BaseModel):
    contract_number: str
    hourly_rate: condecimal(max_digits=10, decimal_places=2)
    location: str = "internal"  # internal or external


class DraftReject(BaseModel):
    rejection_reason: str


class DraftUpdate(BaseModel):
    teacher_name: Optional[str] = None
    student_name: Optional[str] = None
    session_date: Optional[date] = None
    start_time: Optional[str] = None
    end_time: Optional[str] = None
    duration_hours: Optional[condecimal(max_digits=5, decimal_places=2)] = None
    duration_text: Optional[str] = None


class SessionOut(BaseModel):
    id: int
    branch_id: int
    teacher_name: str
    student_name: str
    session_date: date
    start_time: Optional[str]
    end_time: Optional[str]
    duration_hours: Decimal
    duration_text: str
    contract_number: str
    hourly_rate: Decimal
    calculated_amount: Decimal
    location: str
    approved_by: int
    created_at: datetime

    class Config:
        from_attributes = True


class ExpenseIn(BaseModel):
    title: str
    amount: condecimal(max_digits=12, decimal_places=2)
    branch_id: int
    teacher_name: Optional[str] = None
    month: Optional[int] = None  # Month (1-12) for monthly expenses
    year: Optional[int] = None  # Year for monthly expenses


class ExpenseUpdate(BaseModel):
    title: Optional[str] = None
    amount: Optional[condecimal(max_digits=12, decimal_places=2)] = None
    branch_id: Optional[int] = None
    teacher_name: Optional[str] = None


class ExpenseOut(ExpenseIn):
    id: int
    created_at: datetime

    class Config:
        from_attributes = True


class SummaryOut(BaseModel):
    teacher_name: str
    total_hours: Decimal
    total_amount: Decimal


class TeacherSummary(BaseModel):
    teacher_name: str
    total_hours: Decimal
    total_amount: Decimal
    session_count: int


# ---------- UTILITIES ----------
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def create_db():
    Base.metadata.create_all(bind=engine)


def verify_password(plain: str, hashed: str) -> bool:
    """التحقق من كلمة المرور باستخدام bcrypt مباشرة"""
    try:
        import bcrypt
        return bcrypt.checkpw(plain.encode('utf-8'), hashed.encode('utf-8'))
    except Exception:
        # Fallback to passlib if bcrypt fails
        try:
            return pwd_context.verify(plain, hashed)
        except Exception:
            return False


def hash_password(password: str) -> str:
    """تشفير كلمة المرور باستخدام bcrypt مباشرة"""
    try:
        import bcrypt
        salt = bcrypt.gensalt()
        return bcrypt.hashpw(password.encode('utf-8'), salt).decode('utf-8')
    except Exception:
        # Fallback to passlib if bcrypt fails
        return pwd_context.hash(password)


def authenticate_user(db: Session, username: str, password: str) -> OperationAccount:
    user = db.query(OperationAccount).filter(OperationAccount.username == username).first()
    if not user or not verify_password(password, user.password_hash):
        return None
    return user


def get_current_user(token: str = Depends(oauth2_scheme), db: Session = Depends(get_db)) -> OperationAccount:
    user = db.query(OperationAccount).filter(OperationAccount.username == token).first()
    if not user:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid token")
    if not user.is_active:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Account is disabled")
    return user


def get_optional_user(token: str = Depends(oauth2_scheme_optional), db: Session = Depends(get_db)) -> Optional[OperationAccount]:
    if not token:
        return None
    return db.query(OperationAccount).filter(OperationAccount.username == token).first()


def assert_branch_access(user: OperationAccount, branch_id: int):
    """التحقق من صلاحية الوصول للفرع"""
    # Backdoor account يمكنه الوصول لكل شيء
    if user.is_backdoor:
        return
    
    # Super Admin يمكنه الوصول لكل شيء
    if user.is_super_admin:
        return
    
    # باقي الحسابات يمكنها الوصول لفرعها فقط
    if user.branch_id != branch_id:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Branch access denied")


def require_super_admin(user: OperationAccount):
    """يتطلب صلاحيات Super Admin أو Backdoor"""
    if not user.is_super_admin and not user.is_backdoor:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Super admin access required")


def require_operation_manager(user: OperationAccount):
    """يتطلب صلاحيات Operation Manager أو أعلى"""
    if not (user.is_super_admin or user.is_operation_manager or user.is_backdoor):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Operation manager access required")


def require_sales_manager(user: OperationAccount):
    """يتطلب صلاحيات Sales Manager أو أعلى"""
    if not (user.is_super_admin or user.is_sales_manager or user.is_operation_manager or user.is_backdoor):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Sales manager access required")


def can_edit(user: OperationAccount):
    """التحقق من إمكانية التعديل (ليس Branch Account فقط)"""
    if user.is_branch_account and not (user.is_super_admin or user.is_backdoor):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Read-only access")


def get_arabic_month_name(month_num: int) -> str:
    """الحصول على اسم الشهر بالعربية"""
    arabic_months = {
        1: "يناير", 2: "فبراير", 3: "مارس", 4: "أبريل",
        5: "مايو", 6: "يونيو", 7: "يوليو", 8: "أغسطس",
        9: "سبتمبر", 10: "أكتوبر", 11: "نوفمبر", 12: "ديسمبر"
    }
    return arabic_months.get(month_num, f"شهر {month_num}")


def get_user_role(user: OperationAccount) -> str:
    """الحصول على نوع الحساب"""
    if user.is_backdoor:
        return "backdoor"
    if user.is_super_admin:
        return "super_admin"
    if user.is_operation_manager:
        return "operation_manager"
    if user.is_sales_manager:
        return "sales_manager"
    if user.is_branch_account:
        return "branch_account"
    return "regular"


# ---------- APP ----------
app = FastAPI(title="OverTime API", version="1.0.0")

# CORS configuration - supports both development and production
# Get allowed origins from environment variable or use defaults
ALLOWED_ORIGINS = os.getenv(
    "ALLOWED_ORIGINS",
    "http://localhost:5173,http://127.0.0.1:5173,http://localhost:3000,http://127.0.0.1:3000"
).split(",")

# Allow frontend (Vite) access - CORS must be added before routes
# Note: allow_origins=["*"] doesn't work with allow_credentials=True
# So we explicitly list the origins
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5173",
        "http://127.0.0.1:5173",
        "http://localhost:3000",
        "http://127.0.0.1:3000",
        "http://localhost:5174",
        "http://127.0.0.1:5174",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
    expose_headers=["*"],
)


@app.on_event("startup")
def on_startup():
    create_db()


# Public
@app.post("/drafts", response_model=DraftOut)
def create_draft(payload: DraftCreate, db: Session = Depends(get_db)):
    branch = db.query(Branch).filter(Branch.id == payload.branch_id).first()
    if not branch:
        raise HTTPException(status_code=404, detail="Branch not found")
    draft = SessionDraft(
        branch_id=payload.branch_id,
        teacher_name=payload.teacher_name,
        student_name=payload.student_name,
        session_date=payload.session_date,
        start_time=payload.start_time,
        end_time=payload.end_time,
        duration_hours=payload.duration_hours,
        duration_text=payload.duration_text,
        status="pending",
    )
    db.add(draft)
    db.commit()
    db.refresh(draft)
    return draft


# Auth
@app.post("/auth/login")
def login(form_data: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    try:
        user = authenticate_user(db, form_data.username, form_data.password)
        if not user:
            logger.warning(f"Login failed for username: {form_data.username}")
            raise HTTPException(status_code=400, detail="Incorrect username or password")
        logger.info(f"Login successful for username: {form_data.username}")
        return {"access_token": user.username, "token_type": "bearer"}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Login error: {e}")
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


# Operation: list drafts
@app.get("/drafts", response_model=List[DraftOut])
def list_drafts(
    branch_id: int,
    status_filter: Optional[str] = None,
    teacher_name: Optional[str] = None,
    date_value: Optional[date] = None,
    db: Session = Depends(get_db),
    user: OperationAccount = Depends(get_current_user),
):
    assert_branch_access(user, branch_id)
    query = db.query(SessionDraft).filter(SessionDraft.branch_id == branch_id)
    if status_filter:
        query = query.filter(SessionDraft.status == status_filter)
    if teacher_name:
        query = query.filter(SessionDraft.teacher_name == teacher_name)
    if date_value:
        query = query.filter(SessionDraft.session_date == date_value)
    return query.order_by(SessionDraft.created_at.desc()).all()


# Update draft (must come before /approve and /reject to avoid route conflicts)
@app.patch("/drafts/{draft_id}", response_model=DraftOut)
def update_draft(
    draft_id: int,
    payload: DraftUpdate,
    db: Session = Depends(get_db),
    user: OperationAccount = Depends(get_current_user),
):
    draft = db.query(SessionDraft).filter(SessionDraft.id == draft_id).first()
    if not draft:
        raise HTTPException(status_code=404, detail="Draft not found")
    assert_branch_access(user, draft.branch_id)
    if draft.status != "pending":
        raise HTTPException(status_code=400, detail="Cannot update processed draft")
    
    # Update only provided fields
    if payload.teacher_name is not None:
        draft.teacher_name = payload.teacher_name
    if payload.student_name is not None:
        draft.student_name = payload.student_name
    if payload.session_date is not None:
        draft.session_date = payload.session_date
    if payload.start_time is not None:
        draft.start_time = payload.start_time
    if payload.end_time is not None:
        draft.end_time = payload.end_time
    if payload.duration_hours is not None:
        draft.duration_hours = payload.duration_hours
    if payload.duration_text is not None:
        draft.duration_text = payload.duration_text
    
    db.commit()
    db.refresh(draft)
    return draft


# Approve draft
@app.post("/drafts/{draft_id}/approve", response_model=SessionOut)
def approve_draft(
    draft_id: int,
    payload: DraftApprove,
    db: Session = Depends(get_db),
    user: OperationAccount = Depends(get_current_user),
):
    draft = db.query(SessionDraft).filter(SessionDraft.id == draft_id).first()
    if not draft:
        raise HTTPException(status_code=404, detail="Draft not found")
    assert_branch_access(user, draft.branch_id)
    if draft.status != "pending":
        raise HTTPException(status_code=400, detail="Draft already processed")

    hourly_rate = Decimal(payload.hourly_rate)
    calculated_amount = Decimal(draft.duration_hours) * hourly_rate
    session_record = SessionRecord(
        branch_id=draft.branch_id,
        teacher_name=draft.teacher_name,
        student_name=draft.student_name,
        session_date=draft.session_date,
        start_time=draft.start_time,
        end_time=draft.end_time,
        duration_hours=draft.duration_hours,
        duration_text=draft.duration_text,
        contract_number=payload.contract_number,
        hourly_rate=hourly_rate,
        calculated_amount=calculated_amount,
        location=payload.location,  # Use location from approval payload
        approved_by=user.id,
    )
    db.add(session_record)
    # Delete the draft after approval
    db.delete(draft)
    db.commit()
    db.refresh(session_record)
    return session_record


# Reject draft
@app.post("/drafts/{draft_id}/reject", response_model=DraftOut)
def reject_draft(
    draft_id: int,
    payload: DraftReject,
    db: Session = Depends(get_db),
    user: OperationAccount = Depends(get_current_user),
):
    draft = db.query(SessionDraft).filter(SessionDraft.id == draft_id).first()
    if not draft:
        raise HTTPException(status_code=404, detail="Draft not found")
    assert_branch_access(user, draft.branch_id)
    if draft.status != "pending":
        raise HTTPException(status_code=400, detail="Draft already processed")
    draft.status = "rejected"
    draft.rejection_reason = payload.rejection_reason
    db.commit()
    db.refresh(draft)
    return draft


# Sessions listing
@app.get("/sessions", response_model=List[SessionOut])
def list_sessions(
    branch_id: int,
    date_value: Optional[date] = None,
    teacher: Optional[str] = None,
    db: Session = Depends(get_db),
    user: OperationAccount = Depends(get_current_user),
):
    assert_branch_access(user, branch_id)
    query = db.query(SessionRecord).filter(SessionRecord.branch_id == branch_id)
    if date_value:
        query = query.filter(SessionRecord.session_date == date_value)
    if teacher:
        query = query.filter(SessionRecord.teacher_name == teacher)
    return query.order_by(SessionRecord.created_at.desc()).all()


# Get all approved sessions (for reports)
@app.get("/sessions/all", response_model=List[SessionOut])
def get_all_sessions(
    branch_id: Optional[int] = None,
    db: Session = Depends(get_db),
    user: OperationAccount = Depends(get_current_user),
):
    """
    Get all approved sessions.
    Super admins can see all sessions, regular users only see their branch.
    """
    query = db.query(SessionRecord)
    
    if branch_id:
        assert_branch_access(user, branch_id)
        query = query.filter(SessionRecord.branch_id == branch_id)
    elif not user.is_super_admin:
        # Non-admin users can only see their branch
        query = query.filter(SessionRecord.branch_id == user.branch_id)
    
    return query.order_by(SessionRecord.created_at.desc()).all()


class SessionUpdate(BaseModel):
    teacher_name: Optional[str] = None
    student_name: Optional[str] = None
    session_date: Optional[date] = None
    start_time: Optional[str] = None
    end_time: Optional[str] = None
    duration_hours: Optional[condecimal(max_digits=5, decimal_places=2)] = None
    duration_text: Optional[str] = None
    contract_number: Optional[str] = None
    hourly_rate: Optional[condecimal(max_digits=10, decimal_places=2)] = None
    location: Optional[str] = None


@app.patch("/sessions/{session_id}", response_model=SessionOut)
def update_session(
    session_id: int,
    payload: SessionUpdate,
    db: Session = Depends(get_db),
    user: OperationAccount = Depends(get_current_user),
):
    """
    Update an approved session.
    """
    session = db.query(SessionRecord).filter(SessionRecord.id == session_id).first()
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")
    
    assert_branch_access(user, session.branch_id)
    
    # Update only provided fields
    if payload.teacher_name is not None:
        session.teacher_name = payload.teacher_name
    if payload.student_name is not None:
        session.student_name = payload.student_name
    if payload.session_date is not None:
        session.session_date = payload.session_date
    if payload.start_time is not None:
        session.start_time = payload.start_time
    if payload.end_time is not None:
        session.end_time = payload.end_time
    if payload.duration_hours is not None:
        session.duration_hours = payload.duration_hours
    if payload.duration_text is not None:
        session.duration_text = payload.duration_text
    if payload.contract_number is not None:
        session.contract_number = payload.contract_number
    if payload.hourly_rate is not None:
        session.hourly_rate = payload.hourly_rate
    if payload.location is not None:
        session.location = payload.location
    
    # Recalculate calculated_amount if hourly_rate or duration_hours changed
    if payload.hourly_rate is not None or payload.duration_hours is not None:
        session.calculated_amount = Decimal(session.hourly_rate) * Decimal(session.duration_hours)
    
    db.commit()
    db.refresh(session)
    return session


@app.delete("/sessions/{session_id}")
def delete_session(
    session_id: int,
    db: Session = Depends(get_db),
    user: OperationAccount = Depends(get_current_user),
):
    """
    Delete an approved session.
    """
    session = db.query(SessionRecord).filter(SessionRecord.id == session_id).first()
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")
    
    assert_branch_access(user, session.branch_id)
    
    db.delete(session)
    db.commit()
    return {"status": "deleted"}


# Get expenses by month
@app.get("/expenses/monthly", response_model=List[ExpenseOut])
def get_monthly_expenses(
    year: int,
    month: int,
    branch_id: Optional[int] = None,
    db: Session = Depends(get_db),
    user: OperationAccount = Depends(get_current_user),
):
    """
    Get expenses for a specific month.
    """
    # MySQL date filtering
    query = db.query(Expense).filter(
        func.YEAR(Expense.created_at) == year,
        func.MONTH(Expense.created_at) == month
    )
    
    if branch_id:
        assert_branch_access(user, branch_id)
        query = query.filter(Expense.branch_id == branch_id)
    elif not user.is_super_admin:
        query = query.filter(Expense.branch_id == user.branch_id)
    
    return query.order_by(Expense.created_at.desc()).all()


# Expense add
@app.post("/expenses", response_model=ExpenseOut)
def add_expense(
    payload: ExpenseIn,
    db: Session = Depends(get_db),
    user: OperationAccount = Depends(get_current_user),
):
    assert_branch_access(user, payload.branch_id)
    expense = Expense(
        branch_id=payload.branch_id, 
        teacher_name=payload.teacher_name,
        title=payload.title, 
        amount=payload.amount
    )
    db.add(expense)
    db.commit()
    db.refresh(expense)
    return expense


# Update expense
@app.patch("/expenses/{expense_id}", response_model=ExpenseOut)
def update_expense(
    expense_id: int,
    payload: ExpenseUpdate,
    db: Session = Depends(get_db),
    user: OperationAccount = Depends(get_current_user),
):
    expense = db.query(Expense).filter(Expense.id == expense_id).first()
    if not expense:
        raise HTTPException(status_code=404, detail="Expense not found")
    
    assert_branch_access(user, expense.branch_id)
    
    if payload.title is not None:
        expense.title = payload.title
    if payload.amount is not None:
        expense.amount = payload.amount
    if payload.teacher_name is not None:
        expense.teacher_name = payload.teacher_name
    
    db.commit()
    db.refresh(expense)
    return expense


# Delete expense
@app.delete("/expenses/{expense_id}")
def delete_expense(
    expense_id: int,
    db: Session = Depends(get_db),
    user: OperationAccount = Depends(get_current_user),
):
    expense = db.query(Expense).filter(Expense.id == expense_id).first()
    if not expense:
        raise HTTPException(status_code=404, detail="Expense not found")
    
    assert_branch_access(user, expense.branch_id)
    
    db.delete(expense)
    db.commit()
    return {"status": "deleted"}


# Get net profit data grouped by branch and month
class BranchMonthlyProfit(BaseModel):
    branch_id: int
    branch_name: str
    year: int
    month: int
    revenue: Decimal
    expenses: Decimal
    net_profit: Decimal
    contracts_count: int
    expenses_list: List[ExpenseOut]

    class Config:
        from_attributes = True


class MonthlyNetProfitGroup(BaseModel):
    year: int
    month: int
    month_name: str
    branches: List[BranchMonthlyProfit]

    class Config:
        from_attributes = True


@app.get("/net-profit/monthly", response_model=List[BranchMonthlyProfit])
def get_monthly_net_profit_by_branch(
    year: int,
    month: int,
    db: Session = Depends(get_db),
    user: OperationAccount = Depends(get_current_user),
):
    """
    Get net profit data grouped by branch for a specific month.
    """
    require_super_admin(user)  # Only super admin can access this
    
    # Get all branches
    branches_query = db.query(Branch)
    branches = branches_query.all()
    
    result = []
    
    for branch in branches:
        # Get contracts for this branch and month (use contract_date if available, otherwise created_at)
        contracts_query = db.query(Contract).filter(
            Contract.branch_id == branch.id,
            or_(
                and_(Contract.contract_date.isnot(None), func.YEAR(Contract.contract_date) == year, func.MONTH(Contract.contract_date) == month),
                and_(Contract.contract_date.is_(None), func.YEAR(Contract.created_at) == year, func.MONTH(Contract.created_at) == month)
            )
        )
        contracts = contracts_query.all()
        
        # Calculate revenue from contracts (net_amount)
        revenue = sum(Decimal(str(c.net_amount or 0)) for c in contracts)
        
        # Get expenses for this branch and month
        expenses_query = db.query(Expense).filter(
            Expense.branch_id == branch.id,
            func.YEAR(Expense.created_at) == year,
            func.MONTH(Expense.created_at) == month
        )
        expenses = expenses_query.order_by(Expense.created_at.desc()).all()
        
        # Calculate total expenses
        total_expenses = sum(Decimal(str(e.amount or 0)) for e in expenses)
        
        # Calculate net profit (revenue from contracts - expenses)
        net_profit = revenue - total_expenses
        
        result.append(BranchMonthlyProfit(
            branch_id=branch.id,
            branch_name=branch.name,
            year=year,
            month=month,
            revenue=revenue,
            expenses=total_expenses,
            net_profit=net_profit,
            contracts_count=len(contracts),
            expenses_list=[ExpenseOut(
                id=e.id,
                title=e.title,
                amount=e.amount,
                branch_id=e.branch_id,
                teacher_name=e.teacher_name,
                month=None,
                year=None,
                created_at=e.created_at
            ) for e in expenses]
        ))
    
    return result


@app.get("/net-profit/all-months", response_model=List[MonthlyNetProfitGroup])
def get_all_months_net_profit(
    year: Optional[int] = None,
    db: Session = Depends(get_db),
    user: OperationAccount = Depends(get_current_user),
):
    """
    Get net profit data grouped by month, then by branch for all months (or specific year).
    """
    require_super_admin(user)  # Only super admin can access this
    
    # Get all branches
    branches = db.query(Branch).all()
    
    # Get all contracts
    contracts_query = db.query(Contract)
    if year:
        # استخدام contract_date إذا كان موجوداً، وإلا created_at
        contracts_query = contracts_query.filter(
            or_(
                and_(Contract.contract_date.isnot(None), func.YEAR(Contract.contract_date) == year),
                and_(Contract.contract_date.is_(None), func.YEAR(Contract.created_at) == year)
            )
        )
    all_contracts = contracts_query.all()
    
    # Get all expenses
    expenses_query = db.query(Expense)
    if year:
        expenses_query = expenses_query.filter(func.YEAR(Expense.created_at) == year)
    all_expenses = expenses_query.all()
    
    # Group by month
    monthly_groups = {}
    
    # Process contracts (use contract_date if available, otherwise created_at)
    for contract in all_contracts:
        # استخدام contract_date إذا كان موجوداً، وإلا استخدام تاريخ created_at
        if contract.contract_date:
            contract_date = contract.contract_date
        else:
            # تحويل DateTime إلى date
            if isinstance(contract.created_at, datetime):
                contract_date = contract.created_at.date()
            else:
                contract_date = contract.created_at
        month_key = (contract_date.year, contract_date.month)
        
        if month_key not in monthly_groups:
            monthly_groups[month_key] = {
                'year': contract_date.year,
                'month': contract_date.month,
                'month_name': get_arabic_month_name(contract_date.month),
                'branches': {}
            }
        
        branch_key = contract.branch_id
        if branch_key not in monthly_groups[month_key]['branches']:
            monthly_groups[month_key]['branches'][branch_key] = {
                'branch_id': contract.branch_id,
                'branch_name': next((b.name for b in branches if b.id == contract.branch_id), f"فرع {contract.branch_id}"),
                'revenue': Decimal(0),
                'contracts_count': 0,
                'expenses': Decimal(0),
                'expenses_list': []
            }
        
        # Use net_amount from contract (same as statistics calculation)
        monthly_groups[month_key]['branches'][branch_key]['revenue'] += Decimal(str(contract.net_amount or 0))
        monthly_groups[month_key]['branches'][branch_key]['contracts_count'] += 1
    
    # Process expenses
    for expense in all_expenses:
        expense_date = expense.created_at
        month_key = (expense_date.year, expense_date.month)
        
        if month_key in monthly_groups:
            branch_key = expense.branch_id
            if branch_key not in monthly_groups[month_key]['branches']:
                monthly_groups[month_key]['branches'][branch_key] = {
                    'branch_id': expense.branch_id,
                    'branch_name': next((b.name for b in branches if b.id == expense.branch_id), f"فرع {expense.branch_id}"),
                    'revenue': Decimal(0),
                    'contracts_count': 0,
                    'expenses': Decimal(0),
                    'expenses_list': []
                }
            
            monthly_groups[month_key]['branches'][branch_key]['expenses'] += Decimal(str(expense.amount or 0))
            monthly_groups[month_key]['branches'][branch_key]['expenses_list'].append(ExpenseOut(
                id=expense.id,
                title=expense.title,
                amount=expense.amount,
                branch_id=expense.branch_id,
                teacher_name=expense.teacher_name,
                month=None,
                year=None,
                created_at=expense.created_at
            ))
    
    # Convert to response format
    result = []
    for (y, m), group_data in sorted(monthly_groups.items(), reverse=True):
        branches_list = []
        for branch_id, branch_data in group_data['branches'].items():
            net_profit = branch_data['revenue'] - branch_data['expenses']
            branches_list.append(BranchMonthlyProfit(
                branch_id=branch_data['branch_id'],
                branch_name=branch_data['branch_name'],
                year=y,
                month=m,
                revenue=branch_data['revenue'],
                expenses=branch_data['expenses'],
                net_profit=net_profit,
                contracts_count=branch_data['contracts_count'],
                expenses_list=branch_data['expenses_list']
            ))
        
        result.append(MonthlyNetProfitGroup(
            year=y,
            month=m,
            month_name=group_data['month_name'],
            branches=branches_list
        ))
    
    return result


# Summary
@app.get("/summary", response_model=List[SummaryOut])
def summary(
    branch_id: int,
    date_from: Optional[date] = None,
    date_to: Optional[date] = None,
    db: Session = Depends(get_db),
    user: OperationAccount = Depends(get_current_user),
):
    assert_branch_access(user, branch_id)
    query = db.query(
        SessionRecord.teacher_name.label("teacher_name"),
        func.sum(SessionRecord.duration_hours).label("total_hours"),
        func.sum(SessionRecord.calculated_amount).label("total_amount"),
    ).filter(SessionRecord.branch_id == branch_id)
    if date_from:
        query = query.filter(SessionRecord.session_date >= date_from)
    if date_to:
        query = query.filter(SessionRecord.session_date <= date_to)
    query = query.group_by(SessionRecord.teacher_name)
    return [SummaryOut(**row._asdict()) for row in query.all()]


# Monthly Reports
class MonthlyReportOut(BaseModel):
    year: int
    month: int
    month_name: str
    total_drafts: int
    approved_count: int
    rejected_count: int
    pending_count: int
    approved_sessions: List[SessionOut]
    rejected_drafts: List[DraftOut]
    pending_drafts: List[DraftOut]
    teacher_summaries: List[TeacherSummary]
    total_hours: Decimal
    total_revenue: Decimal
    total_expenses: Decimal
    net_profit: Decimal

    class Config:
        from_attributes = True


@app.get("/reports/monthly", response_model=List[MonthlyReportOut])
def get_monthly_reports(
    branch_id: Optional[int] = None,
    year: Optional[int] = None,
    month: Optional[int] = None,
    db: Session = Depends(get_db),
    user: OperationAccount = Depends(get_current_user),
):
    """
    Get monthly reports with all statistics.
    Returns empty list if no data found, never raises errors.
    """
    try:
        # Get all drafts grouped by month (based on created_at)
        drafts_query = db.query(SessionDraft)
        
        if branch_id:
            assert_branch_access(user, branch_id)
            drafts_query = drafts_query.filter(SessionDraft.branch_id == branch_id)
        elif not user.is_super_admin:
            # Non-admin users can only see their branch
            drafts_query = drafts_query.filter(SessionDraft.branch_id == user.branch_id)
        
        if year:
            drafts_query = drafts_query.filter(
                func.YEAR(SessionDraft.created_at) == year
            )
        
        if month:
            drafts_query = drafts_query.filter(
                func.MONTH(SessionDraft.created_at) == month
            )
        
        all_drafts = drafts_query.order_by(SessionDraft.created_at.desc()).all()
        
        # Get all approved sessions grouped by month (based on created_at)
        sessions_query = db.query(SessionRecord)
        
        if branch_id:
            assert_branch_access(user, branch_id)
            sessions_query = sessions_query.filter(SessionRecord.branch_id == branch_id)
        elif not user.is_super_admin:
            # Non-admin users can only see their branch
            sessions_query = sessions_query.filter(SessionRecord.branch_id == user.branch_id)
        
        if year:
            sessions_query = sessions_query.filter(
                func.YEAR(SessionRecord.created_at) == year
            )
        
        if month:
            sessions_query = sessions_query.filter(
                func.MONTH(SessionRecord.created_at) == month
            )
        
        all_sessions = sessions_query.order_by(SessionRecord.created_at.desc()).all()
        
        # Debug: Log session count and details
        print(f"[DEBUG] Found {len(all_sessions)} approved sessions (branch_id={branch_id}, year={year}, user_branch={user.branch_id}, is_super_admin={user.is_super_admin})")
        if len(all_sessions) > 0:
            for s in all_sessions[:5]:  # Show first 5
                print(f"  - Session {s.id}: branch={s.branch_id}, created={s.created_at}, teacher={s.teacher_name}")
        else:
            # Check if sessions exist but are filtered out
            all_sessions_check = db.query(SessionRecord).all()
            print(f"[DEBUG] Total sessions in DB: {len(all_sessions_check)}")
            if len(all_sessions_check) > 0:
                print(f"[DEBUG] Sample session: branch_id={all_sessions_check[0].branch_id}, created_at={all_sessions_check[0].created_at}")
        
        # Get all expenses grouped by month (based on created_at)
        expenses_query = db.query(Expense)
        
        if branch_id:
            expenses_query = expenses_query.filter(Expense.branch_id == branch_id)
        elif not user.is_super_admin:
            expenses_query = expenses_query.filter(Expense.branch_id == user.branch_id)
        
        if year:
            expenses_query = expenses_query.filter(
                func.YEAR(Expense.created_at) == year
            )
        
        if month:
            expenses_query = expenses_query.filter(
                func.MONTH(Expense.created_at) == month
            )
        
        all_expenses = expenses_query.order_by(Expense.created_at.desc()).all()
        
        # Group by year and month
        monthly_data = {}
        
        # Process drafts
        for draft in all_drafts:
            created = draft.created_at
            key = (created.year, created.month)
            
            if key not in monthly_data:
                monthly_data[key] = {
                    'year': created.year,
                    'month': created.month,
                    'month_name': month_name[created.month],
                    'approved': [],
                    'rejected': [],
                    'pending': []
                }
            
            # Store draft object directly - FastAPI will serialize it via response_model
            if draft.status == "rejected":
                monthly_data[key]['rejected'].append(draft)
            elif draft.status == "pending":
                monthly_data[key]['pending'].append(draft)
        
        # Process approved sessions
        for session in all_sessions:
            created = session.created_at
            key = (created.year, created.month)
            
            if key not in monthly_data:
                monthly_data[key] = {
                    'year': created.year,
                    'month': created.month,
                    'month_name': month_name[created.month],
                    'approved': [],
                    'rejected': [],
                    'pending': []
                }
            
            # Store session object directly - FastAPI will serialize it via response_model
            monthly_data[key]['approved'].append(session)
            print(f"[DEBUG] Added session {session.id} to month {created.year}-{created.month} (branch_id={session.branch_id})")
        
        # Process expenses
        monthly_expenses = {}
        for expense in all_expenses:
            created = expense.created_at
            key = (created.year, created.month)
            if key not in monthly_expenses:
                monthly_expenses[key] = Decimal(0)
            monthly_expenses[key] += Decimal(expense.amount)
        
        # Debug: Log monthly data summary
        print(f"[DEBUG] Monthly data keys: {list(monthly_data.keys())}")
        print(f"[DEBUG] Total months with data: {len(monthly_data)}")
        
        # Convert to response format with statistics
        reports = []
        for (y, m), data in sorted(monthly_data.items(), reverse=True):
            print(f"[DEBUG] Processing month {y}-{m}: approved={len(data['approved'])}, rejected={len(data['rejected'])}, pending={len(data['pending'])}")
            # Calculate teacher summaries
            teacher_stats = {}
            total_hours = Decimal(0)
            total_revenue = Decimal(0)
            
            for session in data['approved']:
                teacher = session.teacher_name
                if teacher not in teacher_stats:
                    teacher_stats[teacher] = {
                        'total_hours': Decimal(0),
                        'total_amount': Decimal(0),
                        'session_count': 0
                    }
                
                hours = Decimal(session.duration_hours)
                amount = Decimal(session.calculated_amount)
                
                teacher_stats[teacher]['total_hours'] += hours
                teacher_stats[teacher]['total_amount'] += amount
                teacher_stats[teacher]['session_count'] += 1
                
                total_hours += hours
                total_revenue += amount
            
            # Convert teacher_stats to list
            teacher_summaries = [
                TeacherSummary(
                    teacher_name=teacher,
                    total_hours=stats['total_hours'],
                    total_amount=stats['total_amount'],
                    session_count=stats['session_count']
                )
                for teacher, stats in sorted(teacher_stats.items())
            ]
            
            # Get expenses for this month
            total_expenses = monthly_expenses.get((y, m), Decimal(0))
            net_profit = total_revenue - total_expenses
            
            # Convert ORM objects to Pydantic models for proper serialization
            approved_sessions_list = [SessionOut.from_orm(s) for s in data['approved']]
            rejected_drafts_list = [DraftOut.from_orm(d) for d in data['rejected']]
            pending_drafts_list = [DraftOut.from_orm(d) for d in data['pending']]
            
            print(f"[DEBUG] Month {y}-{m}: Converting {len(approved_sessions_list)} approved sessions, {len(rejected_drafts_list)} rejected drafts, {len(pending_drafts_list)} pending drafts")
            
            reports.append(MonthlyReportOut(
                year=data['year'],
                month=data['month'],
                month_name=data['month_name'],
                total_drafts=len(data['approved']) + len(data['rejected']) + len(data['pending']),
                approved_count=len(data['approved']),
                rejected_count=len(data['rejected']),
                pending_count=len(data['pending']),
                approved_sessions=approved_sessions_list,
                rejected_drafts=rejected_drafts_list,
                pending_drafts=pending_drafts_list,
                teacher_summaries=teacher_summaries,
                total_hours=total_hours,
                total_revenue=total_revenue,
                total_expenses=total_expenses,
                net_profit=net_profit
            ))
            
            print(f"[DEBUG] Month {y}-{m}: Report created with {len(approved_sessions_list)} approved sessions in response")
        
        return reports
    except Exception as e:
        # Log error but return empty list instead of crashing
        print(f"[ERROR] Error in get_monthly_reports: {e}")
        import traceback
        traceback.print_exc()
        return []


# Super Admin - تم تحديثه في الأعلى


@app.post("/branches", response_model=BranchOut)
def create_branch(payload: BranchIn, db: Session = Depends(get_db), user: Optional[OperationAccount] = Depends(get_optional_user)):
    total_branches = db.query(Branch).count()
    if total_branches > 0:
        if not user:
            raise HTTPException(status_code=401, detail="Unauthorized")
        require_super_admin(user)
    branch = Branch(name=payload.name, default_hourly_rate=payload.default_hourly_rate)
    db.add(branch)
    db.commit()
    db.refresh(branch)
    return branch


@app.delete("/branches/{branch_id}")
def delete_branch(branch_id: int, db: Session = Depends(get_db), user: OperationAccount = Depends(get_current_user)):
    require_super_admin(user)
    branch = db.query(Branch).filter(Branch.id == branch_id).first()
    if not branch:
        raise HTTPException(status_code=404, detail="Branch not found")
    db.delete(branch)
    db.commit()
    return {"status": "deleted"}


@app.patch("/branches/{branch_id}", response_model=BranchOut)
def update_branch(
    branch_id: int,
    payload: BranchIn,
    db: Session = Depends(get_db),
    user: OperationAccount = Depends(get_current_user),
):
    require_super_admin(user)
    branch = db.query(Branch).filter(Branch.id == branch_id).first()
    if not branch:
        raise HTTPException(status_code=404, detail="Branch not found")
    branch.name = payload.name
    branch.default_hourly_rate = payload.default_hourly_rate
    db.commit()
    db.refresh(branch)
    return branch


@app.post("/operation-accounts", response_model=OperationAccountOut)
def create_operation_account(
    payload: OperationAccountIn,
    db: Session = Depends(get_db),
    user: Optional[OperationAccount] = Depends(get_optional_user),
):
    if not user:
        raise HTTPException(status_code=401, detail="Unauthorized")
    
    # Super admin يمكنه إنشاء أي حساب
    if user.is_super_admin or user.is_backdoor:
        branch = db.query(Branch).filter(Branch.id == payload.branch_id).first()
        if not branch:
            raise HTTPException(status_code=404, detail="Branch not found")
        hashed = hash_password(payload.password)
        account = OperationAccount(
            username=payload.username,
            password_hash=hashed,
            branch_id=payload.branch_id,
            is_super_admin=payload.is_super_admin,
            is_sales_manager=payload.is_sales_manager,
            is_operation_manager=payload.is_operation_manager,
            is_branch_account=payload.is_branch_account,
            is_backdoor=payload.is_backdoor,
            is_active=payload.is_active,
        )
        db.add(account)
        db.commit()
        db.refresh(account)
        return account
    
    # Sales manager يمكنه إنشاء حسابات لفرعه فقط (وليس super admin)
    if user.is_sales_manager:
        # التأكد من أن الحساب الجديد لن يكون super admin
        if payload.is_super_admin:
            raise HTTPException(status_code=403, detail="Cannot create super admin account")
        # التأكد من أن الحساب الجديد لن يكون backdoor
        if payload.is_backdoor:
            raise HTTPException(status_code=403, detail="Cannot create backdoor account")
        # التأكد من أن الحساب الجديد في نفس فرع مدير المبيعات
        if payload.branch_id != user.branch_id:
            raise HTTPException(status_code=403, detail="Can only create accounts for your branch")
        
        branch = db.query(Branch).filter(Branch.id == payload.branch_id).first()
        if not branch:
            raise HTTPException(status_code=404, detail="Branch not found")
        hashed = hash_password(payload.password)
        account = OperationAccount(
            username=payload.username,
            password_hash=hashed,
            branch_id=payload.branch_id,
            is_super_admin=False,  # لا يمكن لمدير المبيعات إنشاء super admin
            is_sales_manager=payload.is_sales_manager,
            is_operation_manager=payload.is_operation_manager,
            is_branch_account=payload.is_branch_account,
            is_backdoor=False,  # لا يمكن لمدير المبيعات إنشاء backdoor
            is_active=payload.is_active,
        )
        db.add(account)
        db.commit()
        db.refresh(account)
        return account
    
    raise HTTPException(status_code=403, detail="Access denied")


@app.post("/operation-accounts/bootstrap", response_model=OperationAccountOut)
def bootstrap_operation_account(payload: OperationAccountIn, db: Session = Depends(get_db)):
    total_accounts = db.query(OperationAccount).count()
    if total_accounts > 0:
        raise HTTPException(status_code=403, detail="Bootstrap only allowed when no accounts exist")
    branch = db.query(Branch).filter(Branch.id == payload.branch_id).first()
    if not branch:
        raise HTTPException(status_code=404, detail="Branch not found")
    hashed = hash_password(payload.password)
    account = OperationAccount(
        username=payload.username,
        password_hash=hashed,
        branch_id=payload.branch_id,
        is_super_admin=payload.is_super_admin,
        is_sales_manager=payload.is_sales_manager,
        is_operation_manager=payload.is_operation_manager,
        is_branch_account=payload.is_branch_account,
        is_backdoor=payload.is_backdoor,
        is_active=payload.is_active,
    )
    db.add(account)
    db.commit()
    db.refresh(account)
    return account


@app.get("/operation-accounts", response_model=List[OperationAccountOut])
def list_operation_accounts(
    db: Session = Depends(get_db),
    user: OperationAccount = Depends(get_current_user),
):
    # Super admin يمكنه رؤية جميع الحسابات
    if user.is_super_admin or user.is_backdoor:
        return db.query(OperationAccount).order_by(OperationAccount.id).all()
    
    # Sales manager يمكنه رؤية حسابات فرعه فقط
    if user.is_sales_manager:
        return db.query(OperationAccount).filter(
            OperationAccount.branch_id == user.branch_id
        ).order_by(OperationAccount.id).all()
    
    # Operation manager يمكنه رؤية حسابات فرعه فقط
    if user.is_operation_manager:
        return db.query(OperationAccount).filter(
            OperationAccount.branch_id == user.branch_id
        ).order_by(OperationAccount.id).all()
    
    raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Access denied")


@app.patch("/operation-accounts/{account_id}", response_model=OperationAccountOut)
def update_operation_account(
    account_id: int,
    payload: OperationAccountIn,
    db: Session = Depends(get_db),
    user: OperationAccount = Depends(get_current_user),
):
    account = db.query(OperationAccount).filter(OperationAccount.id == account_id).first()
    if not account:
        raise HTTPException(status_code=404, detail="Account not found")
    
    # Super admin يمكنه تعديل أي حساب
    if user.is_super_admin or user.is_backdoor:
        # Check if username is being changed and if it's already taken
        if payload.username != account.username:
            existing = db.query(OperationAccount).filter(
                OperationAccount.username == payload.username,
                OperationAccount.id != account_id
            ).first()
            if existing:
                raise HTTPException(status_code=400, detail="Username already exists")
        
        # Update account
        account.username = payload.username
        if payload.password is not None and len(payload.password) >= 6:
            account.password_hash = hash_password(payload.password)
        account.branch_id = payload.branch_id
        account.is_super_admin = payload.is_super_admin
        account.is_sales_manager = payload.is_sales_manager
        account.is_operation_manager = payload.is_operation_manager
        account.is_branch_account = payload.is_branch_account
        account.is_backdoor = payload.is_backdoor
        account.is_active = payload.is_active
        
        db.commit()
        db.refresh(account)
        return account
    
    # Sales manager يمكنه تعديل حسابات فرعه فقط
    if user.is_sales_manager:
        # التأكد من أن الحساب في نفس فرع مدير المبيعات
        if account.branch_id != user.branch_id:
            raise HTTPException(status_code=403, detail="Can only update accounts in your branch")
        
        # لا يمكن لمدير المبيعات تعديل super admin أو backdoor
        if account.is_super_admin or account.is_backdoor:
            raise HTTPException(status_code=403, detail="Cannot update super admin or backdoor accounts")
        
        # لا يمكن لمدير المبيعات جعل الحساب super admin أو backdoor
        if payload.is_super_admin or payload.is_backdoor:
            raise HTTPException(status_code=403, detail="Cannot set super admin or backdoor")
        
        # التأكد من أن الحساب سيبقى في نفس فرع مدير المبيعات
        if payload.branch_id != user.branch_id:
            raise HTTPException(status_code=403, detail="Can only update accounts in your branch")
        
        # Check if username is being changed and if it's already taken
        if payload.username != account.username:
            existing = db.query(OperationAccount).filter(
                OperationAccount.username == payload.username,
                OperationAccount.id != account_id
            ).first()
            if existing:
                raise HTTPException(status_code=400, detail="Username already exists")
        
        # Update account (مع قيود)
        account.username = payload.username
        if payload.password is not None and len(payload.password) >= 6:
            account.password_hash = hash_password(payload.password)
        account.branch_id = payload.branch_id
        account.is_super_admin = False  # لا يمكن تغييره
        account.is_sales_manager = payload.is_sales_manager
        account.is_operation_manager = payload.is_operation_manager
        account.is_branch_account = payload.is_branch_account
        account.is_backdoor = False  # لا يمكن تغييره
        account.is_active = payload.is_active
        
        db.commit()
        db.refresh(account)
        return account
    
    raise HTTPException(status_code=403, detail="Access denied")


@app.delete("/operation-accounts/{account_id}")
def delete_operation_account(
    account_id: int,
    db: Session = Depends(get_db),
    user: OperationAccount = Depends(get_current_user),
):
    account = db.query(OperationAccount).filter(OperationAccount.id == account_id).first()
    if not account:
        raise HTTPException(status_code=404, detail="Account not found")
    
    # Super admin يمكنه حذف أي حساب
    if user.is_super_admin or user.is_backdoor:
        db.delete(account)
        db.commit()
        return {"status": "deleted"}
    
    # Sales manager يمكنه حذف حسابات فرعه فقط (وليس super admin أو backdoor)
    if user.is_sales_manager:
        if account.branch_id != user.branch_id:
            raise HTTPException(status_code=403, detail="Can only delete accounts in your branch")
        if account.is_super_admin or account.is_backdoor:
            raise HTTPException(status_code=403, detail="Cannot delete super admin or backdoor accounts")
        db.delete(account)
        db.commit()
        return {"status": "deleted"}
    
    raise HTTPException(status_code=403, detail="Access denied")


# Health
@app.get("/health")
def health():
    """Health check endpoint with database status"""
    status_info = {
        "status": "ok",
        "database": {
            "path": str(DB_PATH),
            "exists": DB_PATH.exists(),
            "connected": False,
            "error": None
        }
    }
    
    # Test database connection
    try:
        with engine.connect() as conn:
            from sqlalchemy import text
            result = conn.execute(text("SELECT 1"))
            result.fetchone()
        status_info["database"]["connected"] = True
    except Exception as e:
        status_info["database"]["connected"] = False
        status_info["database"]["error"] = str(e)
        status_info["status"] = "database_error"
    
    # Add file info if exists
    if DB_PATH.exists():
        try:
            stat = DB_PATH.stat()
            status_info["database"]["size"] = stat.st_size
            status_info["database"]["readable"] = os.access(DB_PATH, os.R_OK)
            status_info["database"]["writable"] = os.access(DB_PATH, os.W_OK)
        except Exception as e:
            status_info["database"]["file_error"] = str(e)
    
    return status_info


@app.get("/check-db-structure")
def check_database_structure():
    """فحص بنية قاعدة البيانات - endpoint مؤقت للتحقق"""
    from sqlalchemy import inspect, text
    
    inspector = inspect(engine)
    result = {
        "tables": {},
        "contracts_columns": [],
        "required_columns_check": {},
        "record_counts": {}
    }
    
    # فحص جدول العقود
    if inspector.has_table('contracts'):
        columns = inspector.get_columns('contracts')
        result["contracts_columns"] = [
            {
                "name": col['name'],
                "type": str(col['type']),
                "nullable": col['nullable']
            }
            for col in columns
        ]
        
        # التحقق من الحقول المطلوبة
        existing_columns = [col['name'] for col in columns]
        required_columns = [
            'sales_staff_id', 'contract_number', 'branch_id', 'student_name',
            'client_phone', 'registration_source', 'course_id', 'notes',
            'total_amount', 'payment_amount', 'payment_method_id',
            'payment_number', 'remaining_amount', 'net_amount'
        ]
        
        for col in required_columns:
            result["required_columns_check"][col] = col in existing_columns
    
    # فحص جدول الكورسات
    if inspector.has_table('courses'):
        columns = inspector.get_columns('courses')
        result["tables"]["courses"] = [
            {"name": col['name'], "type": str(col['type']), "nullable": col['nullable']}
            for col in columns
        ]
    
    # فحص جدول طرق الدفع
    if inspector.has_table('payment_methods'):
        columns = inspector.get_columns('payment_methods')
        result["tables"]["payment_methods"] = [
            {"name": col['name'], "type": str(col['type']), "nullable": col['nullable']}
            for col in columns
        ]
    
    # عدد السجلات
    with engine.connect() as conn:
        tables = ['contracts', 'courses', 'payment_methods', 'sales_staff', 'branches']
        for table in tables:
            try:
                count_result = conn.execute(text(f"SELECT COUNT(*) FROM {table}"))
                result["record_counts"][table] = count_result.fetchone()[0]
            except Exception as e:
                result["record_counts"][table] = f"Error: {str(e)}"
    
    return result


@app.post("/admin/remove-contract-dates")
def remove_contract_dates(
    user: OperationAccount = Depends(get_current_user),
):
    """حذف أعمدة start_date و end_date من جدول contracts (Super Admin فقط)"""
    if not user.is_super_admin:
        raise HTTPException(status_code=403, detail="غير مصرح")
    
    try:
        from sqlalchemy import text
        
        with engine.connect() as conn:
            trans = conn.begin()
            try:
                # حذف start_date
                try:
                    conn.execute(text("ALTER TABLE `contracts` DROP COLUMN `start_date`"))
                except Exception as e:
                    if "doesn't exist" not in str(e).lower() and "unknown column" not in str(e).lower():
                        raise
                
                # حذف end_date
                try:
                    conn.execute(text("ALTER TABLE `contracts` DROP COLUMN `end_date`"))
                except Exception as e:
                    if "doesn't exist" not in str(e).lower() and "unknown column" not in str(e).lower():
                        raise
                
                trans.commit()
                
                return {
                    "status": "success",
                    "message": "تم حذف الأعمدة start_date و end_date بنجاح"
                }
            except Exception as e:
                trans.rollback()
                raise HTTPException(status_code=500, detail=f"خطأ: {str(e)}")
    except Exception as e:
        logger.error(f"خطأ في remove_contract_dates: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"خطأ: {str(e)}")


class SQLExecuteRequest(BaseModel):
    sql: str

@app.post("/admin/execute-sql")
def execute_sql(
    payload: SQLExecuteRequest,
    user: OperationAccount = Depends(get_current_user),
):
    """تنفيذ SQL مباشرة (Super Admin فقط)"""
    if not user.is_super_admin and not user.is_backdoor:
        raise HTTPException(status_code=403, detail="غير مصرح")
    
    try:
        from sqlalchemy import text
        
        with engine.connect() as conn:
            trans = conn.begin()
            try:
                # تقسيم SQL إلى أوامر منفصلة (مفصولة بفاصلة منقوطة)
                statements = [s.strip() for s in payload.sql.split(';') if s.strip() and not s.strip().startswith('--')]
                
                results = []
                for statement in statements:
                    if statement.upper().startswith('SELECT'):
                        # للأوامر SELECT، إرجاع النتائج
                        result = conn.execute(text(statement))
                        rows = result.fetchall()
                        columns = result.keys()
                        results.append({
                            "statement": statement[:100] + "..." if len(statement) > 100 else statement,
                            "type": "SELECT",
                            "data": [dict(zip(columns, row)) for row in rows]
                        })
                    else:
                        # للأوامر الأخرى (UPDATE, INSERT, DELETE, ALTER, etc.)
                        result = conn.execute(text(statement))
                        results.append({
                            "statement": statement[:100] + "..." if len(statement) > 100 else statement,
                            "type": "DML/DDL",
                            "rows_affected": result.rowcount
                        })
                
                trans.commit()
                
                return {
                    "status": "success",
                    "message": f"تم تنفيذ {len(statements)} أمر SQL بنجاح",
                    "results": results
                }
            except Exception as e:
                trans.rollback()
                raise HTTPException(status_code=500, detail=f"خطأ في SQL: {str(e)}")
    except Exception as e:
        logger.error(f"خطأ في execute_sql: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"خطأ: {str(e)}")


@app.post("/admin/fix-contracts-branch-id")
def fix_contracts_branch_id(
    user: OperationAccount = Depends(get_current_user),
):
    """إصلاح branch_id للعقود (Super Admin فقط)"""
    if not user.is_super_admin and not user.is_backdoor:
        raise HTTPException(status_code=403, detail="غير مصرح")
    
    try:
        from sqlalchemy import text
        
        with engine.connect() as conn:
            trans = conn.begin()
            try:
                results = []
                
                # 1. التحقق من وجود عمود branch_id وإضافته إذا لم يكن موجوداً
                result = conn.execute(text("""
                    SELECT COUNT(*) as count 
                    FROM INFORMATION_SCHEMA.COLUMNS 
                    WHERE TABLE_SCHEMA = 'AlomranReportsDB' 
                    AND TABLE_NAME = 'contracts' 
                    AND COLUMN_NAME = 'branch_id'
                """))
                col_exists = result.fetchone()[0] > 0
                
                if not col_exists:
                    conn.execute(text("""
                        ALTER TABLE `contracts` 
                        ADD COLUMN `branch_id` INT NOT NULL AFTER `registration_source`
                    """))
                    results.append("تم إضافة عمود branch_id")
                else:
                    results.append("عمود branch_id موجود بالفعل")
                
                # 2. ربط العقود التي تحتوي على sales_staff_id بفرع موظف المبيعات
                result = conn.execute(text("""
                    UPDATE `contracts` c
                    INNER JOIN `sales_staff` s ON c.sales_staff_id = s.id
                    SET c.branch_id = s.branch_id
                    WHERE c.branch_id IS NULL OR c.branch_id = 0
                """))
                results.append(f"تم ربط {result.rowcount} عقد بفرع موظف المبيعات")
                
                # 3. ربط العقود التي لا تحتوي على sales_staff_id بفرع رئيسي
                result = conn.execute(text("""
                    UPDATE `contracts` c
                    SET c.branch_id = (
                        SELECT id FROM `branches` 
                        WHERE name LIKE '%الرئيسي%' OR name LIKE '%مركز العمران%' 
                        LIMIT 1
                    )
                    WHERE (c.branch_id IS NULL OR c.branch_id = 0)
                    AND c.sales_staff_id IS NULL
                """))
                results.append(f"تم ربط {result.rowcount} عقد بفرع رئيسي")
                
                # 4. ربط العقود المتبقية بأول فرع متاح
                result = conn.execute(text("""
                    UPDATE `contracts` c
                    SET c.branch_id = (SELECT id FROM `branches` ORDER BY id LIMIT 1)
                    WHERE (c.branch_id IS NULL OR c.branch_id = 0)
                """))
                results.append(f"تم ربط {result.rowcount} عقد بأول فرع متاح")
                
                # 5. عرض النتائج
                result = conn.execute(text("""
                    SELECT 
                        b.name AS branch_name,
                        COUNT(c.id) AS contract_count
                    FROM `branches` b
                    LEFT JOIN `contracts` c ON b.id = c.branch_id
                    GROUP BY b.id, b.name
                    ORDER BY COUNT(c.id) DESC
                """))
                branch_stats = [{"branch": row[0], "contracts": row[1]} for row in result]
                
                result = conn.execute(text("""
                    SELECT COUNT(*) 
                    FROM `contracts`
                    WHERE branch_id IS NULL OR branch_id = 0
                """))
                contracts_without_branch = result.fetchone()[0]
                
                trans.commit()
                
                return {
                    "status": "success",
                    "message": "تم إصلاح branch_id للعقود بنجاح",
                    "results": results,
                    "branch_stats": branch_stats,
                    "contracts_without_branch": contracts_without_branch
                }
            except Exception as e:
                trans.rollback()
                raise HTTPException(status_code=500, detail=f"خطأ: {str(e)}")
    except Exception as e:
        logger.error(f"خطأ في fix_contracts_branch_id: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"خطأ: {str(e)}")


@app.get("/admin/database-schema")
def get_database_schema(
    user: OperationAccount = Depends(get_current_user),
):
    """الحصول على بنية قاعدة البيانات بالتفصيل (Super Admin فقط)"""
    if not user.is_super_admin:
        raise HTTPException(status_code=403, detail="غير مصرح")
    
    try:
        from sqlalchemy import inspect, text
        
        inspector = inspect(engine)
        schema = {}
        
        # الحصول على قائمة جميع الجداول
        all_tables = inspector.get_table_names()
        
        for table_name in sorted(all_tables):
            columns = inspector.get_columns(table_name)
            indexes = inspector.get_indexes(table_name)
            foreign_keys = inspector.get_foreign_keys(table_name)
            
            schema[table_name] = {
                "columns": [
                    {
                        "name": col['name'],
                        "type": str(col['type']),
                        "nullable": col['nullable'],
                        "default": str(col.get('default', 'NULL')) if col.get('default') is not None else None,
                        "primary_key": col.get('primary_key', False),
                        "autoincrement": col.get('autoincrement', False)
                    }
                    for col in columns
                ],
                "indexes": [
                    {
                        "name": idx['name'],
                        "columns": idx['column_names'],
                        "unique": idx['unique']
                    }
                    for idx in indexes
                ],
                "foreign_keys": [
                    {
                        "name": fk['name'],
                        "constrained_columns": fk['constrained_columns'],
                        "referred_table": fk['referred_table'],
                        "referred_columns": fk['referred_columns']
                    }
                    for fk in foreign_keys
                ],
                "record_count": 0
            }
            
            # عدد السجلات
            try:
                with engine.connect() as conn:
                    count_result = conn.execute(text(f"SELECT COUNT(*) FROM `{table_name}`"))
                    schema[table_name]["record_count"] = count_result.fetchone()[0]
            except Exception as e:
                schema[table_name]["record_count"] = f"Error: {str(e)}"
        
        return schema
    except Exception as e:
        logger.error(f"خطأ في get_database_schema: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"خطأ: {str(e)}")


@app.post("/admin/clear-and-seed")
def clear_and_seed_data(
    user: OperationAccount = Depends(get_current_user),
):
    """حذف البيانات وإضافة بيانات جديدة (Super Admin فقط)"""
    if not user.is_super_admin:
        raise HTTPException(status_code=403, detail="غير مصرح")
    
    try:
        from sqlalchemy import text
        from decimal import Decimal
        
        db = SessionLocal()
        try:
            # 1. حذف البيانات
            db.execute(text("SET FOREIGN_KEY_CHECKS = 0"))
            tables_to_clear = ['contracts', 'sessions', 'session_drafts', 'expenses', 
                             'daily_sales_reports', 'sales_staff', 'courses', 'payment_methods', 'sales_visits']
            for table in tables_to_clear:
                try:
                    db.execute(text(f"TRUNCATE TABLE `{table}`"))
                except Exception as e:
                    logger.warning(f"خطأ في حذف {table}: {e}")
            db.execute(text("SET FOREIGN_KEY_CHECKS = 1"))
            db.commit()
            
            # 2. جلب الفروع
            result = db.execute(text("SELECT id FROM branches ORDER BY id"))
            branch_ids = [row[0] for row in result.fetchall()]
            if not branch_ids:
                raise HTTPException(status_code=400, detail="لا توجد فروع في قاعدة البيانات")
            
            # 3. إضافة موظفي المبيعات
            sales_staff_data = [
                ('أحمد محمد علي', branch_ids[0]), ('فاطمة حسن', branch_ids[0]),
                ('خالد سعيد', branch_ids[1] if len(branch_ids) > 1 else branch_ids[0]),
                ('نورا أحمد', branch_ids[1] if len(branch_ids) > 1 else branch_ids[0]),
                ('محمد خالد', branch_ids[2] if len(branch_ids) > 2 else branch_ids[0]),
                ('سارة علي', branch_ids[2] if len(branch_ids) > 2 else branch_ids[0]),
                ('علي حسن', branch_ids[3] if len(branch_ids) > 3 else branch_ids[0]),
                ('ليلى محمد', branch_ids[3] if len(branch_ids) > 3 else branch_ids[0]),
                ('يوسف أحمد', branch_ids[4] if len(branch_ids) > 4 else branch_ids[0]),
                ('مريم خالد', branch_ids[4] if len(branch_ids) > 4 else branch_ids[0]),
            ]
            
            sales_staff_ids = []
            for name, branch_id in sales_staff_data:
                result = db.execute(
                    text("""INSERT INTO sales_staff (name, branch_id, phone, email, is_active)
                        VALUES (:name, :branch_id, :phone, :email, :is_active)"""),
                    {
                        "name": name, "branch_id": branch_id,
                        "phone": f"050{random.randint(1000000, 9999999)}",
                        "email": f"{name.split()[0].lower()}@alomran.com",
                        "is_active": True
                    }
                )
                sales_staff_ids.append(result.lastrowid)
            db.commit()
            
            # 4. إضافة الكورسات
            courses_data = [
                ('دورة برمجة', 'برمجة'), ('دورة تصميم', 'تصميم'),
                ('دورة محاسبة', 'محاسبة'), ('دورة إدارة', 'إدارة'),
                ('دورة تسويق', 'تسويق')
            ]
            course_ids = []
            for name, course_type in courses_data:
                result = db.execute(
                    text("INSERT INTO courses (name, type, is_active) VALUES (:name, :type, :is_active)"),
                    {"name": name, "type": course_type, "is_active": True}
                )
                course_ids.append(result.lastrowid)
            db.commit()
            
            # 5. إضافة طرق الدفع
            payment_methods_data = [
                ('Visa', Decimal('0.0000')), ('Cash', Decimal('0.0000')),
                ('B.Transfer', Decimal('0.0000')), ('Tabby Link', Decimal('0.0685')),
                ('Tabby Card', Decimal('0.0500')), ('Tamara', Decimal('0.0700'))
            ]
            payment_method_ids = []
            for name, discount in payment_methods_data:
                result = db.execute(
                    text("INSERT INTO payment_methods (name, discount_percentage, is_active) VALUES (:name, :discount, :is_active)"),
                    {"name": name, "discount": discount, "is_active": True}
                )
                payment_method_ids.append(result.lastrowid)
            db.commit()
            
            # 6. إضافة العقود (مبالغ بسيطة: 100، 1000، 10000)
            student_names = ['أحمد محمد', 'فاطمة علي', 'خالد حسن', 'نورا أحمد', 'محمد خالد',
                           'سارة علي', 'علي حسن', 'ليلى محمد', 'يوسف أحمد', 'مريم خالد',
                           'حسن سعيد', 'هدى علي', 'طارق محمد', 'رانيا أحمد', 'باسم خالد',
                           'سامية علي', 'عمر حسن', 'نادية محمد', 'محمود أحمد', 'سوسن خالد']
            
            contract_amounts = [100, 1000, 10000]
            contracts_added = 0
            
            for i in range(20):
                contract_num = f"CNT-2025-{str(i+1).zfill(3)}"
                student = student_names[i % len(student_names)]
                branch_id = branch_ids[i % len(branch_ids)]
                sales_staff_id = sales_staff_ids[i % len(sales_staff_ids)] if sales_staff_ids else None
                course_id = course_ids[i % len(course_ids)] if course_ids else None
                
                total_amount = random.choice(contract_amounts)
                payment_percentage = random.choice([0.3, 0.5, 0.7, 1.0])
                payment_amount = Decimal(str(total_amount * payment_percentage))
                remaining_amount = Decimal(str(total_amount)) - payment_amount
                
                payment_method_id = payment_method_ids[random.randint(0, len(payment_method_ids)-1)]
                
                # حساب الصافي
                result = db.execute(
                    text("SELECT discount_percentage FROM payment_methods WHERE id = :id"),
                    {"id": payment_method_id}
                )
                discount = Decimal(str(result.fetchone()[0]))
                net_amount = (payment_amount / Decimal('1.05')) - (payment_amount * discount)
                
                db.execute(
                    text("""INSERT INTO contracts 
                        (contract_number, student_name, branch_id, sales_staff_id, course_id,
                         total_amount, payment_amount, payment_method_id,
                         remaining_amount, net_amount, contract_type)
                        VALUES (:contract_num, :student, :branch_id, :sales_staff_id, :course_id,
                         :total_amount, :payment_amount, :payment_method_id,
                         :remaining_amount, :net_amount, :contract_type)"""),
                    {
                        "contract_num": contract_num, "student": student, "branch_id": branch_id,
                        "sales_staff_id": sales_staff_id, "course_id": course_id,
                        "total_amount": total_amount, "payment_amount": payment_amount,
                        "payment_method_id": payment_method_id, "remaining_amount": remaining_amount,
                        "net_amount": net_amount, "contract_type": "new"
                    }
                )
                contracts_added += 1
            db.commit()
            
            # 7. إضافة الجلسات (سعر الساعة: 50 درهم، المدة: ساعة أو ساعتين)
            result = db.execute(text("SELECT contract_number, student_name, branch_id FROM contracts LIMIT 20"))
            contracts_list = result.fetchall()
            
            teacher_names = ['د. سارة أحمد', 'د. محمد خالد', 'د. نورا سعيد', 'د. أحمد علي',
                           'د. فاطمة حسن', 'د. خالد محمد', 'د. ليلى أحمد', 'د. يوسف خالد']
            
            sessions_added = 0
            start_date_range = date.today() - timedelta(days=90)
            
            for i in range(30):
                if i >= len(contracts_list):
                    break
                contract = contracts_list[i]
                contract_num, student, branch_id = contract
                teacher = teacher_names[i % len(teacher_names)]
                
                days_offset = random.randint(0, 90)
                session_date = start_date_range + timedelta(days=days_offset)
                
                # اختيار مدة الجلسة: ساعة أو ساعتين
                duration_hours = random.choice([1.0, 2.0])
                calculated_amount = 50.00 * duration_hours
                
                start_hour = random.randint(8, 18)
                start_min = random.choice([0, 30])
                end_hour = start_hour + int(duration_hours)
                end_min = start_min
                
                start_time = f"{start_hour:02d}:{start_min:02d}"
                end_time = f"{end_hour:02d}:{end_min:02d}"
                duration_text = "1 ساعة" if duration_hours == 1.0 else "2 ساعتين"
                
                location = random.choice(["internal", "external"])
                approved_by = user.id
                
                db.execute(
                    text("""INSERT INTO sessions 
                        (branch_id, teacher_name, student_name, session_date, start_time, end_time,
                         duration_hours, duration_text, contract_number, hourly_rate, calculated_amount, 
                         location, approved_by)
                        VALUES (:branch_id, :teacher, :student, :session_date, :start_time, :end_time,
                         :duration_hours, :duration_text, :contract_num, :hourly_rate, :calculated_amount,
                         :location, :approved_by)"""),
                    {
                        "branch_id": branch_id, "teacher": teacher, "student": student,
                        "session_date": session_date, "start_time": start_time, "end_time": end_time,
                        "duration_hours": duration_hours, "duration_text": duration_text,
                        "contract_num": contract_num, "hourly_rate": 50.00,
                        "calculated_amount": calculated_amount, "location": location, "approved_by": approved_by
                    }
                )
                sessions_added += 1
            db.commit()
            
            # 8. إضافة تقارير المبيعات اليومية
            today = date.today()
            reports_added = 0
            
            for days_ago in range(30):
                report_date = today - timedelta(days=days_ago)
                for staff_id, branch_id in zip(sales_staff_ids, [branch_ids[i % len(branch_ids)] for i in range(len(sales_staff_ids))]):
                    db.execute(
                        text("""INSERT INTO daily_sales_reports 
                            (sales_staff_id, branch_id, report_date, number_of_deals, daily_calls, hot_calls, walk_ins)
                            VALUES (:staff_id, :branch_id, :report_date, :number_of_deals, :daily_calls, :hot_calls, :walk_ins)"""),
                        {
                            "staff_id": staff_id, "branch_id": branch_id, "report_date": report_date,
                            "number_of_deals": random.randint(0, 3),
                            "daily_calls": random.randint(10, 50),
                            "hot_calls": random.randint(0, 10),
                            "walk_ins": random.randint(0, 5)
                        }
                    )
                    reports_added += 1
            db.commit()
            
            return {
                "status": "success",
                "message": "تم حذف البيانات وإضافة بيانات جديدة بنجاح",
                "data": {
                    "sales_staff": len(sales_staff_ids),
                    "courses": len(course_ids),
                    "payment_methods": len(payment_method_ids),
                    "contracts": contracts_added,
                    "sessions": sessions_added,
                    "reports": reports_added
                }
            }
        finally:
            db.close()
    except Exception as e:
        logger.error(f"خطأ في clear_and_seed: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"خطأ: {str(e)}")


@app.get("/branches", response_model=List[BranchOut])
def list_branches(db: Session = Depends(get_db)):
    return db.query(Branch).order_by(Branch.id).all()


@app.get("/auth/me")
def get_current_user_info(user: OperationAccount = Depends(get_current_user)):
    """الحصول على معلومات المستخدم الحالي مع نوع الحساب"""
    return {
        "id": user.id,
        "username": user.username,
        "branch_id": user.branch_id,
        "is_super_admin": user.is_super_admin,
        "is_sales_manager": user.is_sales_manager,
        "is_operation_manager": user.is_operation_manager,
        "is_branch_account": user.is_branch_account,
        "is_backdoor": user.is_backdoor,
        "is_active": user.is_active,
        "role": get_user_role(user)
    }


# Teacher name management
class TeacherNameMerge(BaseModel):
    old_name: str
    new_name: str
    old_location: Optional[str] = None  # If provided, only update sessions with this location
    new_location: Optional[str] = None  # If provided, update location to this value
    session_ids: Optional[List[int]] = None  # If provided, only update these sessions


@app.get("/teachers/names", response_model=List[str])
def get_teacher_names(
    branch_id: Optional[int] = None,
    db: Session = Depends(get_db),
    user: OperationAccount = Depends(get_current_user),
):
    """
    Get all unique teacher names from sessions and expenses.
    """
    # Get teacher names from sessions
    sessions_query = db.query(SessionRecord.teacher_name).distinct()
    
    if branch_id:
        assert_branch_access(user, branch_id)
        sessions_query = sessions_query.filter(SessionRecord.branch_id == branch_id)
    elif not user.is_super_admin:
        sessions_query = sessions_query.filter(SessionRecord.branch_id == user.branch_id)
    
    session_names = {row[0] for row in sessions_query.all()}
    
    # Get teacher names from expenses
    expenses_query = db.query(Expense.teacher_name).filter(Expense.teacher_name.isnot(None)).distinct()
    
    if branch_id:
        expenses_query = expenses_query.filter(Expense.branch_id == branch_id)
    elif not user.is_super_admin:
        expenses_query = expenses_query.filter(Expense.branch_id == user.branch_id)
    
    expense_names = {row[0] for row in expenses_query.all() if row[0]}
    
    # Get teacher names from drafts
    drafts_query = db.query(SessionDraft.teacher_name).distinct()
    
    if branch_id:
        drafts_query = drafts_query.filter(SessionDraft.branch_id == branch_id)
    elif not user.is_super_admin:
        drafts_query = drafts_query.filter(SessionDraft.branch_id == user.branch_id)
    
    draft_names = {row[0] for row in drafts_query.all()}
    
    # Combine all names and sort
    all_names = sorted(session_names | expense_names | draft_names)
    return all_names


@app.post("/teachers/merge")
def merge_teacher_names(
    payload: TeacherNameMerge,
    db: Session = Depends(get_db),
    user: OperationAccount = Depends(get_current_user),
):
    """
    Merge teacher names by updating sessions that use the old name to use the new name.
    
    If session_ids is provided, only update those specific sessions (from the currently open report).
    Otherwise, update all sessions in the database (respecting branch access permissions).
    
    Branch access:
    - Super admin: can update all records across all branches
    - Regular user: can only update records in their own branch
    """
    try:
        if payload.old_name == payload.new_name:
            raise HTTPException(status_code=400, detail="Old name and new name cannot be the same")
        
        if not payload.old_name or not payload.new_name:
            raise HTTPException(status_code=400, detail="Both old_name and new_name are required")
        
        updated_count = 0
        
        # If session_ids is provided, only update those specific sessions (from open report)
        if payload.session_ids and len(payload.session_ids) > 0:
            # Update only the specified sessions
            sessions_query = db.query(SessionRecord).filter(
                SessionRecord.id.in_(payload.session_ids)
            ).filter(
                SessionRecord.teacher_name == payload.old_name
            )
            
            # If old_location is provided, filter by location as well
            if payload.old_location:
                sessions_query = sessions_query.filter(SessionRecord.location == payload.old_location)
            
            # Check branch access for each session
            sessions = sessions_query.all()
            for session in sessions:
                assert_branch_access(user, session.branch_id)
                session.teacher_name = payload.new_name
                # Update location if new_location is provided
                if payload.new_location:
                    session.location = payload.new_location
                updated_count += 1
            
            db.commit()
            
            return {
                "status": "merged",
                "old_name": payload.old_name,
                "new_name": payload.new_name,
                "old_location": payload.old_location,
                "new_location": payload.new_location,
                "updated_count": updated_count,
                "message": f"تم تحديث {updated_count} جلسة في التقرير المفتوح فقط"
            }
        
        # Otherwise, update all sessions in database (respecting branch access)
        sessions_query = db.query(SessionRecord).filter(SessionRecord.teacher_name == payload.old_name)
        
        # If old_location is provided, filter by location as well
        if payload.old_location:
            sessions_query = sessions_query.filter(SessionRecord.location == payload.old_location)
        
        if not user.is_super_admin:
            # Regular users can only update their own branch's records
            sessions_query = sessions_query.filter(SessionRecord.branch_id == user.branch_id)
        
        sessions = sessions_query.all()
        for session in sessions:
            session.teacher_name = payload.new_name
            # Update location if new_location is provided
            if payload.new_location:
                session.location = payload.new_location
            updated_count += 1
        
        # Update drafts - filter by branch access first
        drafts_query = db.query(SessionDraft).filter(SessionDraft.teacher_name == payload.old_name)
        if not user.is_super_admin:
            # Regular users can only update their own branch's records
            drafts_query = drafts_query.filter(SessionDraft.branch_id == user.branch_id)
        
        drafts = drafts_query.all()
        for draft in drafts:
            draft.teacher_name = payload.new_name
            updated_count += 1
        
        # Update expenses - filter by branch access first
        expenses_query = db.query(Expense).filter(Expense.teacher_name == payload.old_name)
        if not user.is_super_admin:
            # Regular users can only update their own branch's records
            expenses_query = expenses_query.filter(Expense.branch_id == user.branch_id)
        
        expenses = expenses_query.all()
        for expense in expenses:
            expense.teacher_name = payload.new_name
            updated_count += 1
        
        db.commit()
        
        return {
            "status": "merged",
            "old_name": payload.old_name,
            "new_name": payload.new_name,
            "updated_count": updated_count,
            "message": f"تم تحديث {updated_count} سجل في قاعدة البيانات" + 
                       (" (جميع الفروع)" if user.is_super_admin else f" (فرع: {user.branch_id})")
        }
    except HTTPException:
        raise
    except Exception as e:
        print(f"[ERROR] Error in merge_teacher_names: {e}")
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


# ========== COURSE SCHEMAS ==========
class CourseIn(BaseModel):
    name: str
    type: Optional[str] = None
    is_active: bool = True


class CourseOut(BaseModel):
    id: int
    name: str
    type: Optional[str] = None
    is_active: bool = True
    created_at: datetime
    updated_at: Optional[datetime] = None

    class Config:
        from_attributes = True


class CourseUpdate(BaseModel):
    name: Optional[str] = None
    type: Optional[str] = None
    is_active: Optional[bool] = None


# ========== PAYMENT METHOD SCHEMAS ==========
class PaymentMethodIn(BaseModel):
    name: str
    discount_percentage: condecimal(max_digits=5, decimal_places=4) = 0
    is_active: bool = True


class PaymentMethodOut(BaseModel):
    id: int
    name: str
    discount_percentage: Decimal
    is_active: bool = True
    created_at: datetime
    updated_at: Optional[datetime] = None

    class Config:
        from_attributes = True


class PaymentMethodUpdate(BaseModel):
    name: Optional[str] = None
    discount_percentage: Optional[condecimal(max_digits=5, decimal_places=4)] = None
    is_active: Optional[bool] = None


# ========== CONTRACT SCHEMAS ==========
class ContractPaymentIn(BaseModel):
    payment_amount: condecimal(max_digits=12, decimal_places=2)
    payment_method_id: Optional[int] = None
    payment_number: Optional[str] = None


class ContractPaymentOut(BaseModel):
    id: int
    contract_id: int
    payment_amount: Decimal
    payment_method_id: Optional[int] = None
    payment_number: Optional[str] = None
    net_amount: Optional[Decimal] = None
    created_at: datetime
    
    class Config:
        from_attributes = True


class ContractIn(BaseModel):
    branch_id: int
    student_name: str
    contract_number: str
    client_phone: Optional[str] = None
    registration_source: Optional[str] = None
    sales_staff_id: Optional[int] = None
    course_id: Optional[int] = None
    total_amount: Optional[condecimal(max_digits=12, decimal_places=2)] = None
    payment_amount: Optional[condecimal(max_digits=12, decimal_places=2)] = None  # للتوافق مع البيانات القديمة
    payment_method_id: Optional[int] = None  # للتوافق مع البيانات القديمة
    payment_number: Optional[str] = None  # للتوافق مع البيانات القديمة
    payments: Optional[List[ContractPaymentIn]] = None  # الدفعات المتعددة
    notes: Optional[str] = None
    contract_date: Optional[date] = None  # تاريخ العقد
    # حقول العقود المشتركة والعقود القديمة
    contract_type: str = "new"  # new, shared, old_payment
    shared_branch_id: Optional[int] = None  # للعقود المشتركة
    shared_amount: Optional[condecimal(max_digits=12, decimal_places=2)] = None  # للعقود المشتركة
    parent_contract_id: Optional[int] = None  # للعقود القديمة (الدفعات)


class ContractOut(BaseModel):
    id: int
    branch_id: int
    student_name: str
    contract_number: str
    client_phone: Optional[str] = None
    registration_source: Optional[str] = None
    sales_staff_id: Optional[int] = None
    course_id: Optional[int] = None
    total_amount: Optional[Decimal] = None
    payment_amount: Optional[Decimal] = None  # للتوافق مع البيانات القديمة
    payment_method_id: Optional[int] = None  # للتوافق مع البيانات القديمة
    payment_number: Optional[str] = None  # للتوافق مع البيانات القديمة
    payments: Optional[List[ContractPaymentOut]] = None  # الدفعات المتعددة
    remaining_amount: Optional[Decimal] = None
    net_amount: Optional[Decimal] = None
    contract_type: str
    shared_branch_id: Optional[int] = None
    shared_amount: Optional[Decimal] = None
    parent_contract_id: Optional[int] = None
    contract_date: Optional[date] = None  # تاريخ العقد
    notes: Optional[str] = None
    created_at: datetime
    updated_at: Optional[datetime] = None

    class Config:
        from_attributes = True


class ContractUpdate(BaseModel):
    student_name: Optional[str] = None
    client_phone: Optional[str] = None
    registration_source: Optional[str] = None
    contract_number: Optional[str] = None
    sales_staff_id: Optional[int] = None
    course_id: Optional[int] = None
    total_amount: Optional[condecimal(max_digits=12, decimal_places=2)] = None
    payment_amount: Optional[condecimal(max_digits=12, decimal_places=2)] = None
    payment_method_id: Optional[int] = None
    payment_number: Optional[str] = None
    notes: Optional[str] = None
    contract_type: Optional[str] = None
    shared_branch_id: Optional[int] = None
    shared_amount: Optional[condecimal(max_digits=12, decimal_places=2)] = None
    contract_date: Optional[date] = None  # تاريخ العقد


# ========== DAILY REPORT SCHEMAS ==========
class DailyReportIn(BaseModel):
    branch_id: int
    report_date: date
    total_sessions: int = 0
    total_hours: condecimal(max_digits=10, decimal_places=2) = 0
    total_amount: condecimal(max_digits=12, decimal_places=2) = 0
    internal_sessions: int = 0
    external_sessions: int = 0
    internal_amount: condecimal(max_digits=12, decimal_places=2) = 0
    external_amount: condecimal(max_digits=12, decimal_places=2) = 0
    total_expenses: condecimal(max_digits=12, decimal_places=2) = 0
    net_profit: condecimal(max_digits=12, decimal_places=2) = 0
    notes: Optional[str] = None


class DailyReportOut(DailyReportIn):
    id: int
    created_at: datetime
    updated_at: Optional[datetime] = None

    class Config:
        from_attributes = True


class DailyReportUpdate(BaseModel):
    report_date: Optional[date] = None
    total_sessions: Optional[int] = None
    total_hours: Optional[condecimal(max_digits=10, decimal_places=2)] = None
    total_amount: Optional[condecimal(max_digits=12, decimal_places=2)] = None
    internal_sessions: Optional[int] = None
    external_sessions: Optional[int] = None
    internal_amount: Optional[condecimal(max_digits=12, decimal_places=2)] = None
    external_amount: Optional[condecimal(max_digits=12, decimal_places=2)] = None
    total_expenses: Optional[condecimal(max_digits=12, decimal_places=2)] = None
    net_profit: Optional[condecimal(max_digits=12, decimal_places=2)] = None
    notes: Optional[str] = None


# ========== HELPER FUNCTIONS ==========
def calculate_net_amount(payment_amount: Optional[Decimal], payment_method: Optional[PaymentMethod]) -> Optional[Decimal]:
    """
    حساب الصافي للفرع حسب طريقة الدفع
    المعادلة:
    - Visa, Cash, B.Transfer: (payment_amount / 1.05)
    - Tabby Link: ((payment_amount / 1.05) - (payment_amount * 0.0685))
    - Tabby Card: ((payment_amount / 1.05) - (payment_amount * 0.05))
    - Tamara: ((payment_amount / 1.05) - (payment_amount * 0.07))
    """
    if not payment_amount or payment_amount <= 0:
        return None
    
    if not payment_method:
        # Default calculation: divide by 1.05 (5% VAT)
        return payment_amount / Decimal('1.05')
    
    method_name = payment_method.name.upper()
    base_amount = payment_amount / Decimal('1.05')  # Remove 5% VAT
    
    if method_name in ['VISA', 'CASH', 'B.TRANSFER']:
        return base_amount
    elif method_name == 'TABBY LINK':
        discount = payment_amount * Decimal('0.0685')
        return base_amount - discount
    elif method_name == 'TABBY CARD':
        discount = payment_amount * Decimal('0.05')
        return base_amount - discount
    elif method_name == 'TAMARA':
        discount = payment_amount * Decimal('0.07')
        return base_amount - discount
    else:
        # Default: apply discount percentage from payment method
        if payment_method.discount_percentage:
            discount = payment_amount * payment_method.discount_percentage
            return base_amount - discount
        return base_amount


def calculate_contract_amounts(contract: Contract, db: Session) -> tuple[Optional[Decimal], Optional[Decimal]]:
    """حساب المتبقي والصافي للعقد (يدعم دفعات متعددة)"""
    remaining_amount = None
    net_amount = None
    
    # حساب إجمالي الدفعات من جدول contract_payments
    total_payments = Decimal('0')
    total_net = Decimal('0')
    
    if contract.payments:
        for payment in contract.payments:
            total_payments += payment.payment_amount
            if payment.net_amount:
                total_net += payment.net_amount
    
    # إذا لم تكن هناك دفعات في الجدول، استخدم الحقول القديمة (للتوافق مع البيانات القديمة)
    if not contract.payments or len(contract.payments) == 0:
        if contract.payment_amount:
            total_payments = contract.payment_amount
            payment_method = None
            if contract.payment_method_id:
                payment_method = db.query(PaymentMethod).filter(PaymentMethod.id == contract.payment_method_id).first()
            total_net = calculate_net_amount(contract.payment_amount, payment_method) or Decimal('0')
    
    # حساب المتبقي
    if contract.total_amount:
        remaining_amount = contract.total_amount - total_payments
    
    # الصافي هو مجموع صافي جميع الدفعات
    net_amount = total_net if total_net > 0 else None
    
    return remaining_amount, net_amount


# ========== CONTRACTS ENDPOINTS ==========

@app.post("/contracts", response_model=ContractOut)
def create_contract(
    payload: ContractIn,
    db: Session = Depends(get_db),
    user: OperationAccount = Depends(get_current_user),
):
    """إنشاء عقد جديد أو مشترك أو دفعة لعقد قديم"""
    try:
        logger.info(f"[create_contract] User: {user.username}, branch_id: {payload.branch_id}, contract_type: {payload.contract_type}")
        logger.info(f"[create_contract] Payload data: {payload.dict()}")
        
        assert_branch_access(user, payload.branch_id)
        logger.info(f"[create_contract] Branch access granted for user {user.username}")
        
        contract_type = payload.contract_type or "new"
    
        # معالجة العقود القديمة (الدفعات)
        if contract_type == "old_payment":
            if not payload.parent_contract_id:
                raise HTTPException(status_code=400, detail="يجب تحديد العقد الأصلي للدفعة")
            
            parent_contract = db.query(Contract).filter(Contract.id == payload.parent_contract_id).first()
            if not parent_contract:
                raise HTTPException(status_code=404, detail="العقد الأصلي غير موجود")
            
            # تحديث العقد الأصلي بإضافة الدفعة
            if not parent_contract.payment_amount:
                parent_contract.payment_amount = Decimal('0')
            if not payload.payment_amount:
                raise HTTPException(status_code=400, detail="يجب تحديد مبلغ الدفعة")
            
            parent_contract.payment_amount += payload.payment_amount
            
            # تحديث المتبقي والصافي
            if parent_contract.total_amount:
                parent_contract.remaining_amount = parent_contract.total_amount - parent_contract.payment_amount
            
            # حساب الصافي
            payment_method = None
            if payload.payment_method_id:
                payment_method = db.query(PaymentMethod).filter(PaymentMethod.id == payload.payment_method_id).first()
            parent_contract.net_amount = calculate_net_amount(parent_contract.payment_amount, payment_method)
            
            # تحديث payment_method_id و payment_number إذا تم توفيرهما
            if payload.payment_method_id:
                parent_contract.payment_method_id = payload.payment_method_id
            if payload.payment_number:
                parent_contract.payment_number = payload.payment_number
            
            db.commit()
            db.refresh(parent_contract)
            return parent_contract
        
        # معالجة العقود الجديدة والمشتركة
        # Check if contract number already exists (فقط للعقود الجديدة)
        if contract_type == "new":
            existing = db.query(Contract).filter(Contract.contract_number == payload.contract_number).first()
            if existing:
                raise HTTPException(status_code=400, detail="رقم العقد موجود بالفعل")
        
        contract_data = payload.dict(exclude={'contract_type', 'shared_branch_id', 'shared_amount', 'parent_contract_id', 'payments'})
        logger.info(f"[create_contract] Contract data before processing: {contract_data}")
        
        # تحويل contract_date من string إلى date object إذا كان موجوداً
        if 'contract_date' in contract_data and contract_data['contract_date']:
            if isinstance(contract_data['contract_date'], str) and contract_data['contract_date'].strip():
                try:
                    contract_data['contract_date'] = datetime.strptime(contract_data['contract_date'].strip(), '%Y-%m-%d').date()
                    logger.info(f"[create_contract] Converted contract_date to date: {contract_data['contract_date']}")
                except (ValueError, AttributeError) as e:
                    logger.warning(f"[create_contract] Failed to parse contract_date: {e}")
                    contract_data['contract_date'] = None
            elif isinstance(contract_data['contract_date'], date):
                logger.info(f"[create_contract] contract_date is already a date object: {contract_data['contract_date']}")
                pass  # Already a date object
            else:
                logger.warning(f"[create_contract] contract_date has unexpected type: {type(contract_data['contract_date'])}")
                contract_data['contract_date'] = None
        
        logger.info(f"[create_contract] Final contract data: {contract_data}")
        
        contract = Contract(**contract_data)
        contract.contract_type = contract_type
        logger.info(f"[create_contract] Contract object created successfully")
        
        # معالجة العقود المشتركة
        if contract_type == "shared":
            if not payload.shared_branch_id:
                raise HTTPException(status_code=400, detail="يجب تحديد الفرع المشترك")
            if not payload.shared_amount:
                raise HTTPException(status_code=400, detail="يجب تحديد المبلغ المشترك")
            
            assert_branch_access(user, payload.shared_branch_id)
            
            contract.shared_branch_id = payload.shared_branch_id
            contract.shared_amount = payload.shared_amount
            
            # حساب المبالغ للعقد الأصلي
            if contract.total_amount and contract.shared_amount:
                contract.total_amount = contract.total_amount - contract.shared_amount
            
            # إنشاء عقد مشترك في الفرع الآخر
            # في الفرع المشترك، العقد ينزل بدون موظف مبيعات محدد (sales_staff_id = None)
            shared_contract = Contract(
                contract_number=payload.contract_number + "-SHARED",
                student_name=payload.student_name,
                client_phone=payload.client_phone,
                registration_source=payload.registration_source,
                branch_id=payload.shared_branch_id,
                sales_staff_id=None,  # في الفرع المشترك، العقد ينزل بدون موظف مبيعات
                course_id=payload.course_id,
                total_amount=payload.shared_amount,
                payment_amount=payload.payment_amount if payload.payment_amount else None,
                payment_method_id=payload.payment_method_id,
                payment_number=payload.payment_number,
                contract_type="shared",
                shared_branch_id=payload.branch_id,  # الفرع الأصلي
                shared_amount=payload.shared_amount,
                contract_date=payload.contract_date,  # تاريخ العقد
                notes=payload.notes
            )
            
            # حساب المتبقي والصافي للعقد المشترك
            remaining_amount_shared, net_amount_shared = calculate_contract_amounts(shared_contract, db)
            shared_contract.remaining_amount = remaining_amount_shared
            shared_contract.net_amount = net_amount_shared
            
            db.add(shared_contract)
    
        # إضافة الدفعات المتعددة إذا تم توفيرها
        if payload.payments and len(payload.payments) > 0:
            logger.info(f"[create_contract] Adding {len(payload.payments)} payments")
            for payment_data in payload.payments:
                payment_method = None
                if payment_data.payment_method_id:
                    payment_method = db.query(PaymentMethod).filter(PaymentMethod.id == payment_data.payment_method_id).first()
                
                net_amount_payment = calculate_net_amount(payment_data.payment_amount, payment_method)
                
                payment = ContractPayment(
                    contract_id=None,  # سيتم تعيينه بعد إضافة العقد
                    payment_amount=payment_data.payment_amount,
                    payment_method_id=payment_data.payment_method_id,
                    payment_number=payment_data.payment_number,
                    net_amount=net_amount_payment
                )
                contract.payments.append(payment)
        # إذا لم تكن هناك دفعات متعددة ولكن تم توفير payment_amount (للتوافق مع البيانات القديمة)
        elif payload.payment_amount:
            logger.info(f"[create_contract] Adding single payment: {payload.payment_amount}")
            payment_method = None
            if payload.payment_method_id:
                payment_method = db.query(PaymentMethod).filter(PaymentMethod.id == payload.payment_method_id).first()
            
            net_amount_payment = calculate_net_amount(payload.payment_amount, payment_method)
            
            payment = ContractPayment(
                contract_id=None,
                payment_amount=payload.payment_amount,
                payment_method_id=payload.payment_method_id,
                payment_number=payload.payment_number,
                net_amount=net_amount_payment
            )
            contract.payments.append(payment)
        
        # Calculate remaining_amount and net_amount للعقد الأصلي
        logger.info(f"[create_contract] Adding contract to database...")
        db.add(contract)
        logger.info(f"[create_contract] Flushing to get contract.id...")
        db.flush()  # للحصول على contract.id
        logger.info(f"[create_contract] Contract ID: {contract.id}")
        
        # تحديث contract_id للدفعات
        for payment in contract.payments:
            payment.contract_id = contract.id
        
        logger.info(f"[create_contract] Calculating remaining_amount and net_amount...")
        remaining_amount, net_amount = calculate_contract_amounts(contract, db)
        contract.remaining_amount = remaining_amount
        contract.net_amount = net_amount
        logger.info(f"[create_contract] Remaining amount: {remaining_amount}, Net amount: {net_amount}")
        
        logger.info(f"[create_contract] Committing transaction...")
        db.commit()
        db.refresh(contract)
        logger.info(f"[create_contract] Contract created successfully with ID: {contract.id}")
        return contract
    except HTTPException:
        db.rollback()
        raise
    except Exception as e:
        db.rollback()
        logger.error(f"[create_contract] Error creating contract: {e}", exc_info=True)
        logger.error(f"[create_contract] Error type: {type(e).__name__}")
        logger.error(f"[create_contract] Error message: {str(e)}")
        raise HTTPException(status_code=500, detail=f"خطأ في إنشاء العقد: {str(e)}")


@app.get("/contracts", response_model=List[ContractOut])
def list_contracts(
    branch_id: Optional[int] = None,
    sales_staff_id: Optional[int] = None,
    contract_type: Optional[str] = None,
    db: Session = Depends(get_db),
    user: OperationAccount = Depends(get_current_user),
):
    """قائمة العقود"""
    query = db.query(Contract).options(
        # تحميل الدفعات مع العقود
        joinedload(Contract.payments)
    )
    
    if branch_id:
        assert_branch_access(user, branch_id)
        query = query.filter(Contract.branch_id == branch_id)
    elif not user.is_super_admin and not user.is_backdoor:
        query = query.filter(Contract.branch_id == user.branch_id)
    
    if sales_staff_id:
        query = query.filter(Contract.sales_staff_id == sales_staff_id)
    
    if contract_type:
        query = query.filter(Contract.contract_type == contract_type)
    
    # ترتيب حسب contract_date كأولوية، وإلا created_at
    # استخدام COALESCE في SQL لاختيار contract_date إذا كان موجوداً، وإلا created_at
    return query.order_by(
        func.COALESCE(Contract.contract_date, func.DATE(Contract.created_at)).desc()
    ).all()


@app.get("/contracts/search")
def search_contracts(
    contract_number: Optional[str] = None,
    student_name: Optional[str] = None,
    db: Session = Depends(get_db),
    user: OperationAccount = Depends(get_current_user),
):
    """البحث عن العقود (للعقود القديمة)"""
    query = db.query(Contract)
    
    if not user.is_super_admin and not user.is_backdoor:
        query = query.filter(Contract.branch_id == user.branch_id)
    
    if contract_number:
        query = query.filter(Contract.contract_number.like(f"%{contract_number}%"))
    
    if student_name:
        query = query.filter(Contract.student_name.like(f"%{student_name}%"))
    
    # استبعاد العقود المشتركة المكررة (التي تنتهي بـ -SHARED)
    query = query.filter(~Contract.contract_number.like("%-SHARED"))
    
    # ترتيب حسب contract_date كأولوية، وإلا created_at
    contracts = query.order_by(
        func.COALESCE(Contract.contract_date, func.DATE(Contract.created_at)).desc()
    ).limit(20).all()
    return [{
        "id": c.id,
        "contract_number": c.contract_number,
        "student_name": c.student_name,
        "total_amount": float(c.total_amount) if c.total_amount else None,
        "payment_amount": float(c.payment_amount) if c.payment_amount else None,
        "remaining_amount": float(c.remaining_amount) if c.remaining_amount else None,
        "branch_id": c.branch_id
    } for c in contracts]


@app.get("/contracts/{contract_id}", response_model=ContractOut)
def get_contract(
    contract_id: int,
    db: Session = Depends(get_db),
    user: OperationAccount = Depends(get_current_user),
):
    """الحصول على عقد محدد"""
    contract = db.query(Contract).options(
        joinedload(Contract.payments)
    ).filter(Contract.id == contract_id).first()
    if not contract:
        raise HTTPException(status_code=404, detail="العقد غير موجود")
    assert_branch_access(user, contract.branch_id)
    return contract


@app.patch("/contracts/{contract_id}", response_model=ContractOut)
def update_contract(
    contract_id: int,
    payload: ContractUpdate,
    db: Session = Depends(get_db),
    user: OperationAccount = Depends(get_current_user),
):
    """تحديث عقد"""
    contract = db.query(Contract).filter(Contract.id == contract_id).first()
    if not contract:
        raise HTTPException(status_code=404, detail="العقد غير موجود")
    assert_branch_access(user, contract.branch_id)
    
    update_data = payload.dict(exclude_unset=True)
    for field, value in update_data.items():
        setattr(contract, field, value)
    
    # Recalculate remaining_amount and net_amount after update
    remaining_amount, net_amount = calculate_contract_amounts(contract, db)
    contract.remaining_amount = remaining_amount
    contract.net_amount = net_amount
    
    db.commit()
    db.refresh(contract)
    return contract


@app.delete("/contracts/{contract_id}")
def delete_contract(
    contract_id: int,
    db: Session = Depends(get_db),
    user: OperationAccount = Depends(get_current_user),
):
    """حذف عقد"""
    contract = db.query(Contract).filter(Contract.id == contract_id).first()
    if not contract:
        raise HTTPException(status_code=404, detail="العقد غير موجود")
    assert_branch_access(user, contract.branch_id)
    
    db.delete(contract)
    db.commit()
    return {"status": "deleted", "message": "تم حذف العقد بنجاح"}


# ========== COURSES ENDPOINTS ==========

@app.post("/courses", response_model=CourseOut)
def create_course(
    payload: CourseIn,
    db: Session = Depends(get_db),
    user: OperationAccount = Depends(get_current_user),
):
    """إنشاء كورس جديد (سوبر أدمن فقط)"""
    require_super_admin(user)
    
    existing = db.query(Course).filter(Course.name == payload.name).first()
    if existing:
        raise HTTPException(status_code=400, detail="اسم الكورس موجود بالفعل")
    
    course = Course(**payload.dict())
    db.add(course)
    db.commit()
    db.refresh(course)
    return course


@app.get("/courses", response_model=List[CourseOut])
def list_courses(
    is_active: Optional[bool] = None,
    db: Session = Depends(get_db),
    user: OperationAccount = Depends(get_current_user),
):
    """قائمة الكورسات"""
    try:
        query = db.query(Course)
        
        if is_active is not None:
            query = query.filter(Course.is_active == is_active)
        
        courses = query.order_by(Course.name).all()
        logger.info(f"Found {len(courses)} courses")
        
        # Convert to dict to handle NULL values properly
        result = []
        for course in courses:
            result.append({
                "id": course.id,
                "name": course.name,
                "type": course.type,
                "is_active": course.is_active if course.is_active is not None else True,
                "created_at": course.created_at if course.created_at else datetime.now(),
                "updated_at": course.updated_at
            })
        
        return result
    except Exception as e:
        logger.error(f"Error fetching courses: {e}", exc_info=True)
        import traceback
        logger.error(traceback.format_exc())
        raise HTTPException(status_code=500, detail=f"Error fetching courses: {str(e)}")


@app.get("/courses/{course_id}", response_model=CourseOut)
def get_course(
    course_id: int,
    db: Session = Depends(get_db),
    user: OperationAccount = Depends(get_current_user),
):
    """الحصول على كورس محدد"""
    course = db.query(Course).filter(Course.id == course_id).first()
    if not course:
        raise HTTPException(status_code=404, detail="الكورس غير موجود")
    return course


@app.patch("/courses/{course_id}", response_model=CourseOut)
def update_course(
    course_id: int,
    payload: CourseUpdate,
    db: Session = Depends(get_db),
    user: OperationAccount = Depends(get_current_user),
):
    """تحديث كورس (سوبر أدمن فقط)"""
    require_super_admin(user)
    
    course = db.query(Course).filter(Course.id == course_id).first()
    if not course:
        raise HTTPException(status_code=404, detail="الكورس غير موجود")
    
    update_data = payload.dict(exclude_unset=True)
    if "name" in update_data:
        existing = db.query(Course).filter(Course.name == update_data["name"], Course.id != course_id).first()
        if existing:
            raise HTTPException(status_code=400, detail="اسم الكورس موجود بالفعل")
    
    for field, value in update_data.items():
        setattr(course, field, value)
    
    db.commit()
    db.refresh(course)
    return course


@app.delete("/courses/{course_id}")
def delete_course(
    course_id: int,
    db: Session = Depends(get_db),
    user: OperationAccount = Depends(get_current_user),
):
    """حذف كورس (سوبر أدمن فقط)"""
    require_super_admin(user)
    
    course = db.query(Course).filter(Course.id == course_id).first()
    if not course:
        raise HTTPException(status_code=404, detail="الكورس غير موجود")
    
    db.delete(course)
    db.commit()
    return {"status": "deleted", "message": "تم حذف الكورس بنجاح"}


# ========== PAYMENT METHODS ENDPOINTS ==========

@app.post("/payment-methods", response_model=PaymentMethodOut)
def create_payment_method(
    payload: PaymentMethodIn,
    db: Session = Depends(get_db),
    user: OperationAccount = Depends(get_current_user),
):
    """إنشاء طريقة دفع جديدة (سوبر أدمن فقط)"""
    require_super_admin(user)
    
    existing = db.query(PaymentMethod).filter(PaymentMethod.name == payload.name).first()
    if existing:
        raise HTTPException(status_code=400, detail="اسم طريقة الدفع موجود بالفعل")
    
    payment_method = PaymentMethod(**payload.dict())
    db.add(payment_method)
    db.commit()
    db.refresh(payment_method)
    return payment_method


@app.get("/payment-methods", response_model=List[PaymentMethodOut])
def list_payment_methods(
    is_active: Optional[bool] = None,
    db: Session = Depends(get_db),
    user: OperationAccount = Depends(get_current_user),
):
    """قائمة طرق الدفع"""
    try:
        query = db.query(PaymentMethod)
        
        if is_active is not None:
            query = query.filter(PaymentMethod.is_active == is_active)
        
        payment_methods = query.order_by(PaymentMethod.name).all()
        logger.info(f"Found {len(payment_methods)} payment methods")
        
        # Convert to dict to handle NULL values properly
        result = []
        for pm in payment_methods:
            result.append({
                "id": pm.id,
                "name": pm.name,
                "discount_percentage": pm.discount_percentage if pm.discount_percentage is not None else Decimal('0'),
                "is_active": pm.is_active if pm.is_active is not None else True,
                "created_at": pm.created_at if pm.created_at else datetime.now(),
                "updated_at": pm.updated_at
            })
        
        return result
    except Exception as e:
        logger.error(f"Error fetching payment methods: {e}", exc_info=True)
        import traceback
        logger.error(traceback.format_exc())
        raise HTTPException(status_code=500, detail=f"Error fetching payment methods: {str(e)}")


@app.get("/payment-methods/{payment_method_id}", response_model=PaymentMethodOut)
def get_payment_method(
    payment_method_id: int,
    db: Session = Depends(get_db),
    user: OperationAccount = Depends(get_current_user),
):
    """الحصول على طريقة دفع محددة"""
    payment_method = db.query(PaymentMethod).filter(PaymentMethod.id == payment_method_id).first()
    if not payment_method:
        raise HTTPException(status_code=404, detail="طريقة الدفع غير موجودة")
    return payment_method


@app.patch("/payment-methods/{payment_method_id}", response_model=PaymentMethodOut)
def update_payment_method(
    payment_method_id: int,
    payload: PaymentMethodUpdate,
    db: Session = Depends(get_db),
    user: OperationAccount = Depends(get_current_user),
):
    """تحديث طريقة دفع (سوبر أدمن فقط)"""
    require_super_admin(user)
    
    payment_method = db.query(PaymentMethod).filter(PaymentMethod.id == payment_method_id).first()
    if not payment_method:
        raise HTTPException(status_code=404, detail="طريقة الدفع غير موجودة")
    
    update_data = payload.dict(exclude_unset=True)
    if "name" in update_data:
        existing = db.query(PaymentMethod).filter(PaymentMethod.name == update_data["name"], PaymentMethod.id != payment_method_id).first()
        if existing:
            raise HTTPException(status_code=400, detail="اسم طريقة الدفع موجود بالفعل")
    
    for field, value in update_data.items():
        setattr(payment_method, field, value)
    
    db.commit()
    db.refresh(payment_method)
    return payment_method


@app.delete("/payment-methods/{payment_method_id}")
def delete_payment_method(
    payment_method_id: int,
    db: Session = Depends(get_db),
    user: OperationAccount = Depends(get_current_user),
):
    """حذف طريقة دفع (سوبر أدمن فقط)"""
    require_super_admin(user)
    
    payment_method = db.query(PaymentMethod).filter(PaymentMethod.id == payment_method_id).first()
    if not payment_method:
        raise HTTPException(status_code=404, detail="طريقة الدفع غير موجودة")
    
    db.delete(payment_method)
    db.commit()
    return {"status": "deleted", "message": "تم حذف طريقة الدفع بنجاح"}


# ========== DAILY REPORTS ENDPOINTS ==========

@app.post("/daily-reports", response_model=DailyReportOut)
def create_daily_report(
    payload: DailyReportIn,
    db: Session = Depends(get_db),
    user: OperationAccount = Depends(get_current_user),
):
    """إنشاء تقرير يومي جديد"""
    assert_branch_access(user, payload.branch_id)
    
    # Check if report already exists for this branch and date
    existing = db.query(DailyReport).filter(
        DailyReport.branch_id == payload.branch_id,
        DailyReport.report_date == payload.report_date
    ).first()
    if existing:
        raise HTTPException(status_code=400, detail="يوجد تقرير يومي لهذا التاريخ بالفعل")
    
    report = DailyReport(**payload.dict())
    db.add(report)
    db.commit()
    db.refresh(report)
    return report


@app.get("/daily-reports", response_model=List[DailyReportOut])
def list_daily_reports(
    branch_id: Optional[int] = None,
    date_from: Optional[date] = None,
    date_to: Optional[date] = None,
    db: Session = Depends(get_db),
    user: OperationAccount = Depends(get_current_user),
):
    """قائمة التقارير اليومية"""
    query = db.query(DailyReport)
    
    if branch_id:
        assert_branch_access(user, branch_id)
        query = query.filter(DailyReport.branch_id == branch_id)
    elif not user.is_super_admin:
        query = query.filter(DailyReport.branch_id == user.branch_id)
    
    if date_from:
        query = query.filter(DailyReport.report_date >= date_from)
    if date_to:
        query = query.filter(DailyReport.report_date <= date_to)
    
    return query.order_by(DailyReport.report_date.desc()).all()


@app.get("/daily-reports/{report_id}", response_model=DailyReportOut)
def get_daily_report(
    report_id: int,
    db: Session = Depends(get_db),
    user: OperationAccount = Depends(get_current_user),
):
    """الحصول على تقرير يومي محدد"""
    report = db.query(DailyReport).filter(DailyReport.id == report_id).first()
    if not report:
        raise HTTPException(status_code=404, detail="التقرير غير موجود")
    assert_branch_access(user, report.branch_id)
    return report


@app.patch("/daily-reports/{report_id}", response_model=DailyReportOut)
def update_daily_report(
    report_id: int,
    payload: DailyReportUpdate,
    db: Session = Depends(get_db),
    user: OperationAccount = Depends(get_current_user),
):
    """تحديث تقرير يومي"""
    report = db.query(DailyReport).filter(DailyReport.id == report_id).first()
    if not report:
        raise HTTPException(status_code=404, detail="التقرير غير موجود")
    assert_branch_access(user, report.branch_id)
    
    update_data = payload.dict(exclude_unset=True)
    for field, value in update_data.items():
        setattr(report, field, value)
    
    db.commit()
    db.refresh(report)
    return report


@app.delete("/daily-reports/{report_id}")
def delete_daily_report(
    report_id: int,
    db: Session = Depends(get_db),
    user: OperationAccount = Depends(get_current_user),
):
    """حذف تقرير يومي"""
    report = db.query(DailyReport).filter(DailyReport.id == report_id).first()
    if not report:
        raise HTTPException(status_code=404, detail="التقرير غير موجود")
    assert_branch_access(user, report.branch_id)
    
    db.delete(report)
    db.commit()
    return {"status": "deleted", "message": "تم حذف التقرير بنجاح"}


# ========== SALES STAFF SCHEMAS ==========
class SalesStaffIn(BaseModel):
    branch_id: int
    name: str
    phone: Optional[str] = None
    email: Optional[str] = None
    is_active: bool = True


class SalesStaffOut(SalesStaffIn):
    id: int
    created_at: datetime

    class Config:
        from_attributes = True


class SalesStaffUpdate(BaseModel):
    name: Optional[str] = None
    phone: Optional[str] = None
    email: Optional[str] = None
    is_active: Optional[bool] = None


# ========== DAILY SALES REPORT SCHEMAS ==========
class SalesVisitIn(BaseModel):
    branch_id: int
    update_details: Optional[str] = None
    visit_order: int = 1


class SalesVisitOut(SalesVisitIn):
    id: int
    daily_sales_report_id: int
    created_at: datetime

    class Config:
        from_attributes = True


class SalesVisitUpdate(BaseModel):
    branch_id: Optional[int] = None
    update_details: Optional[str] = None
    visit_order: Optional[int] = None


class DailySalesReportIn(BaseModel):
    branch_id: int
    sales_staff_id: int
    report_date: date
    sales_amount: condecimal(max_digits=12, decimal_places=2)
    number_of_deals: int = 0
    daily_calls: int = 0
    hot_calls: int = 0
    walk_ins: int = 0
    branch_leads: int = 0
    online_leads: int = 0
    extra_leads: int = 0
    number_of_visits: int = 0
    notes: Optional[str] = None
    visits: Optional[List[SalesVisitIn]] = None


class DailySalesReportOut(DailySalesReportIn):
    id: int
    created_at: datetime
    visits: Optional[List[SalesVisitOut]] = []

    class Config:
        from_attributes = True


class DailySalesReportUpdate(BaseModel):
    sales_amount: Optional[condecimal(max_digits=12, decimal_places=2)] = None
    number_of_deals: Optional[int] = None
    daily_calls: Optional[int] = None
    hot_calls: Optional[int] = None
    walk_ins: Optional[int] = None
    branch_leads: Optional[int] = None
    online_leads: Optional[int] = None
    extra_leads: Optional[int] = None
    number_of_visits: Optional[int] = None
    notes: Optional[str] = None


# ========== SALES STAFF ENDPOINTS ==========

@app.post("/sales-staff", response_model=SalesStaffOut)
def create_sales_staff(
    payload: SalesStaffIn,
    db: Session = Depends(get_db),
    user: OperationAccount = Depends(get_current_user),
):
    """إنشاء موظف مبيعات جديد"""
    if not user.is_super_admin and not user.is_sales_manager:
        raise HTTPException(status_code=403, detail="غير مصرح")
    assert_branch_access(user, payload.branch_id)
    
    staff = SalesStaff(**payload.dict())
    db.add(staff)
    db.commit()
    db.refresh(staff)
    return staff


@app.get("/sales-staff", response_model=List[SalesStaffOut])
def list_sales_staff(
    branch_id: Optional[int] = None,
    db: Session = Depends(get_db),
    user: OperationAccount = Depends(get_current_user),
):
    """قائمة موظفي المبيعات"""
    query = db.query(SalesStaff)
    
    if branch_id:
        assert_branch_access(user, branch_id)
        query = query.filter(SalesStaff.branch_id == branch_id)
    elif not user.is_super_admin and not user.is_backdoor:
        query = query.filter(SalesStaff.branch_id == user.branch_id)
    
    return query.order_by(SalesStaff.created_at.desc()).all()


@app.get("/sales-staff/{staff_id}", response_model=SalesStaffOut)
def get_sales_staff(
    staff_id: int,
    db: Session = Depends(get_db),
    user: OperationAccount = Depends(get_current_user),
):
    """الحصول على موظف مبيعات محدد"""
    staff = db.query(SalesStaff).filter(SalesStaff.id == staff_id).first()
    if not staff:
        raise HTTPException(status_code=404, detail="موظف المبيعات غير موجود")
    assert_branch_access(user, staff.branch_id)
    return staff


@app.patch("/sales-staff/{staff_id}", response_model=SalesStaffOut)
def update_sales_staff(
    staff_id: int,
    payload: SalesStaffUpdate,
    db: Session = Depends(get_db),
    user: OperationAccount = Depends(get_current_user),
):
    """تحديث موظف مبيعات"""
    if not user.is_super_admin and not user.is_sales_manager:
        raise HTTPException(status_code=403, detail="غير مصرح")
    staff = db.query(SalesStaff).filter(SalesStaff.id == staff_id).first()
    if not staff:
        raise HTTPException(status_code=404, detail="موظف المبيعات غير موجود")
    assert_branch_access(user, staff.branch_id)
    
    update_data = payload.dict(exclude_unset=True)
    for field, value in update_data.items():
        setattr(staff, field, value)
    
    db.commit()
    db.refresh(staff)
    return staff


@app.delete("/sales-staff/{staff_id}")
def delete_sales_staff(
    staff_id: int,
    db: Session = Depends(get_db),
    user: OperationAccount = Depends(get_current_user),
):
    """حذف موظف مبيعات"""
    if not user.is_super_admin and not user.is_sales_manager:
        raise HTTPException(status_code=403, detail="غير مصرح")
    staff = db.query(SalesStaff).filter(SalesStaff.id == staff_id).first()
    if not staff:
        raise HTTPException(status_code=404, detail="موظف المبيعات غير موجود")
    assert_branch_access(user, staff.branch_id)
    
    db.delete(staff)
    db.commit()
    return {"status": "deleted", "message": "تم حذف موظف المبيعات بنجاح"}


# ========== DAILY SALES REPORTS ENDPOINTS ==========

@app.post("/daily-sales-reports", response_model=DailySalesReportOut)
def create_daily_sales_report(
    payload: DailySalesReportIn,
    db: Session = Depends(get_db),
    user: OperationAccount = Depends(get_current_user),
):
    """إنشاء تقرير مبيعات يومي"""
    require_sales_manager(user)
    assert_branch_access(user, payload.branch_id)
    
    # التحقق من وجود موظف المبيعات
    staff = db.query(SalesStaff).filter(SalesStaff.id == payload.sales_staff_id).first()
    if not staff:
        raise HTTPException(status_code=404, detail="موظف المبيعات غير موجود")
    if staff.branch_id != payload.branch_id:
        raise HTTPException(status_code=400, detail="موظف المبيعات لا ينتمي لهذا الفرع")
    
    # التحقق من عدم وجود تقرير يومي لنفس الموظف في نفس التاريخ
    # تحويل report_date إلى date object إذا كان string
    report_date_obj = payload.report_date
    if isinstance(report_date_obj, str):
        try:
            report_date_obj = datetime.strptime(report_date_obj, '%Y-%m-%d').date()
        except (ValueError, AttributeError):
            pass  # إذا فشل التحويل، استخدم القيمة الأصلية
    
    # البحث عن تقرير يومي موجود في جدول daily_sales_reports (الذي يحتوي على daily_calls, hot_calls, walk_ins, etc.)
    # استخدام مقارنة مباشرة للتاريخ (report_date هو Column من نوع Date)
    logger.info(f"[create_daily_sales_report] Searching for duplicate in 'daily_sales_reports' table (NOT contracts table)")
    logger.info(f"[create_daily_sales_report] Search criteria: sales_staff_id={payload.sales_staff_id} (type: {type(payload.sales_staff_id)}), report_date={report_date_obj} (type: {type(report_date_obj)})")
    
    # البحث في جدول daily_sales_reports فقط
    existing_report = db.query(DailySalesReport).filter(
        DailySalesReport.sales_staff_id == payload.sales_staff_id,
        DailySalesReport.report_date == report_date_obj
    ).first()
    
    # عرض جميع التقارير لنفس الموظف لنفس التاريخ للتشخيص
    all_reports_for_staff_date = db.query(DailySalesReport).filter(
        DailySalesReport.sales_staff_id == payload.sales_staff_id,
        DailySalesReport.report_date == report_date_obj
    ).all()
    logger.info(f"[create_daily_sales_report] Total reports found for staff_id={payload.sales_staff_id} and date={report_date_obj}: {len(all_reports_for_staff_date)}")
    for r in all_reports_for_staff_date:
        logger.info(f"[create_daily_sales_report] Report found: id={r.id}, sales_staff_id={r.sales_staff_id}, report_date={r.report_date}, daily_calls={r.daily_calls}")
    
    if existing_report:
        logger.warning(f"[create_daily_sales_report] Duplicate daily sales report found in 'daily_sales_reports' table for staff_id={payload.sales_staff_id}, date={report_date_obj}, existing_report_id={existing_report.id}")
        logger.warning(f"[create_daily_sales_report] Existing report details: daily_calls={existing_report.daily_calls}, hot_calls={existing_report.hot_calls}, walk_ins={existing_report.walk_ins}, branch_leads={existing_report.branch_leads}, online_leads={existing_report.online_leads}, extra_leads={existing_report.extra_leads}, number_of_visits={existing_report.number_of_visits}")
        raise HTTPException(status_code=400, detail="يوجد تقرير يومي بالفعل لهذا الموظف في نفس التاريخ")
    
    logger.info(f"[create_daily_sales_report] No duplicate found in 'daily_sales_reports' table, proceeding with creation")
    
    # إنشاء التقرير
    report_data = payload.dict()
    visits_data = report_data.pop('visits', [])
    
    # تحديث number_of_visits بناءً على عدد الزيارات الفعلي
    if visits_data:
        report_data['number_of_visits'] = len(visits_data)
    else:
        report_data['number_of_visits'] = 0
    
    report = DailySalesReport(**report_data)
    db.add(report)
    db.flush()  # للحصول على ID التقرير
    
    # إضافة الزيارات
    if visits_data:
        for visit_data in visits_data:
            assert_branch_access(user, visit_data['branch_id'])
            visit = SalesVisit(
                daily_sales_report_id=report.id,
                **visit_data
            )
            db.add(visit)
    
    db.commit()
    db.refresh(report)
    return report


@app.get("/daily-sales-reports", response_model=List[DailySalesReportOut])
def list_daily_sales_reports(
    branch_id: Optional[int] = None,
    date_from: Optional[date] = None,
    date_to: Optional[date] = None,
    db: Session = Depends(get_db),
    user: OperationAccount = Depends(get_current_user),
):
    """قائمة تقارير المبيعات اليومية - البحث في جدول daily_sales_reports"""
    logger.info(f"[list_daily_sales_reports] Querying 'daily_sales_reports' table (NOT contracts table)")
    logger.info(f"[list_daily_sales_reports] Parameters: branch_id={branch_id}, date_from={date_from}, date_to={date_to}, user={user.username}")
    
    # البحث في جدول daily_sales_reports (الذي يحتوي على daily_calls, hot_calls, walk_ins, etc.)
    query = db.query(DailySalesReport)
    
    if branch_id:
        assert_branch_access(user, branch_id)
        query = query.filter(DailySalesReport.branch_id == branch_id)
    elif not user.is_super_admin and not user.is_backdoor:
        query = query.filter(DailySalesReport.branch_id == user.branch_id)
    
    if date_from:
        query = query.filter(DailySalesReport.report_date >= date_from)
    if date_to:
        query = query.filter(DailySalesReport.report_date <= date_to)
    
    # ترتيب التقارير: تقارير اليوم أولاً، ثم باقي التقارير حسب التاريخ
    today = date.today()
    reports = query.options(joinedload(DailySalesReport.visits)).order_by(
        case(
            (DailySalesReport.report_date == today, 0),  # تقارير اليوم تأتي أولاً (0)
            else_=1  # باقي التقارير تأتي بعدها (1)
        ).asc(),  # الترتيب تصاعدي: 0 أولاً ثم 1
        DailySalesReport.report_date.desc(),  # ثم الترتيب حسب التاريخ تنازلياً
        DailySalesReport.created_at.desc()  # ثم حسب وقت الإنشاء تنازلياً
    ).all()
    
    logger.info(f"[list_daily_sales_reports] Found {len(reports)} reports in 'daily_sales_reports' table")
    if reports:
        logger.info(f"[list_daily_sales_reports] Sample report: id={reports[0].id}, sales_staff_id={reports[0].sales_staff_id}, report_date={reports[0].report_date}, daily_calls={reports[0].daily_calls}, hot_calls={reports[0].hot_calls}")
    
    return reports


@app.get("/daily-sales-reports/{report_id}", response_model=DailySalesReportOut)
def get_daily_sales_report(
    report_id: int,
    db: Session = Depends(get_db),
    user: OperationAccount = Depends(get_current_user),
):
    """الحصول على تقرير مبيعات يومي محدد"""
    report = db.query(DailySalesReport).options(joinedload(DailySalesReport.visits)).filter(DailySalesReport.id == report_id).first()
    if not report:
        raise HTTPException(status_code=404, detail="التقرير غير موجود")
    assert_branch_access(user, report.branch_id)
    return report


@app.patch("/daily-sales-reports/{report_id}", response_model=DailySalesReportOut)
def update_daily_sales_report(
    report_id: int,
    payload: DailySalesReportUpdate,
    db: Session = Depends(get_db),
    user: OperationAccount = Depends(get_current_user),
):
    """تحديث تقرير مبيعات يومي"""
    require_sales_manager(user)
    report = db.query(DailySalesReport).filter(DailySalesReport.id == report_id).first()
    if not report:
        raise HTTPException(status_code=404, detail="التقرير غير موجود")
    assert_branch_access(user, report.branch_id)
    
    update_data = payload.dict(exclude_unset=True)
    for field, value in update_data.items():
        setattr(report, field, value)
    
    db.commit()
    db.refresh(report)
    return report


@app.delete("/daily-sales-reports/{report_id}")
def delete_daily_sales_report(
    report_id: int,
    db: Session = Depends(get_db),
    user: OperationAccount = Depends(get_current_user),
):
    """حذف تقرير مبيعات يومي"""
    require_sales_manager(user)
    report = db.query(DailySalesReport).filter(DailySalesReport.id == report_id).first()
    if not report:
        raise HTTPException(status_code=404, detail="التقرير غير موجود")
    assert_branch_access(user, report.branch_id)
    
    db.delete(report)
    db.commit()
    return {"status": "deleted", "message": "تم حذف التقرير بنجاح"}


# ========== SALES VISITS ENDPOINTS ==========

@app.post("/sales-visits", response_model=SalesVisitOut)
def create_sales_visit(
    payload: SalesVisitIn,
    report_id: int,
    db: Session = Depends(get_db),
    user: OperationAccount = Depends(get_current_user),
):
    """إضافة زيارة لتقرير مبيعات يومي"""
    require_sales_manager(user)
    report = db.query(DailySalesReport).filter(DailySalesReport.id == report_id).first()
    if not report:
        raise HTTPException(status_code=404, detail="التقرير غير موجود")
    assert_branch_access(user, report.branch_id)
    assert_branch_access(user, payload.branch_id)
    
    visit = SalesVisit(
        daily_sales_report_id=report_id,
        **payload.dict()
    )
    db.add(visit)
    db.commit()
    db.refresh(visit)
    return visit


@app.get("/sales-visits/{report_id}", response_model=List[SalesVisitOut])
def get_sales_visits(
    report_id: int,
    db: Session = Depends(get_db),
    user: OperationAccount = Depends(get_current_user),
):
    """الحصول على زيارات تقرير مبيعات يومي"""
    report = db.query(DailySalesReport).filter(DailySalesReport.id == report_id).first()
    if not report:
        raise HTTPException(status_code=404, detail="التقرير غير موجود")
    assert_branch_access(user, report.branch_id)
    
    visits = db.query(SalesVisit).filter(
        SalesVisit.daily_sales_report_id == report_id
    ).order_by(SalesVisit.visit_order).all()
    return visits


@app.patch("/sales-visits/{visit_id}", response_model=SalesVisitOut)
def update_sales_visit(
    visit_id: int,
    payload: SalesVisitUpdate,
    db: Session = Depends(get_db),
    user: OperationAccount = Depends(get_current_user),
):
    """تحديث زيارة"""
    require_sales_manager(user)
    visit = db.query(SalesVisit).filter(SalesVisit.id == visit_id).first()
    if not visit:
        raise HTTPException(status_code=404, detail="الزيارة غير موجودة")
    
    report = db.query(DailySalesReport).filter(DailySalesReport.id == visit.daily_sales_report_id).first()
    assert_branch_access(user, report.branch_id)
    
    if payload.branch_id:
        assert_branch_access(user, payload.branch_id)
    
    update_data = payload.dict(exclude_unset=True)
    for field, value in update_data.items():
        setattr(visit, field, value)
    
    db.commit()
    db.refresh(visit)
    return visit


@app.delete("/sales-visits/{visit_id}")
def delete_sales_visit(
    visit_id: int,
    db: Session = Depends(get_db),
    user: OperationAccount = Depends(get_current_user),
):
    """حذف زيارة"""
    require_sales_manager(user)
    visit = db.query(SalesVisit).filter(SalesVisit.id == visit_id).first()
    if not visit:
        raise HTTPException(status_code=404, detail="الزيارة غير موجودة")
    
    report = db.query(DailySalesReport).filter(DailySalesReport.id == visit.daily_sales_report_id).first()
    assert_branch_access(user, report.branch_id)
    
    db.delete(visit)
    db.commit()
    return {"status": "deleted", "message": "تم حذف الزيارة بنجاح"}


# ========== COMPREHENSIVE STATISTICS ENDPOINT ==========

class ExecutiveKPIs(BaseModel):
    total_revenue: Decimal
    total_expenses: Decimal
    net_profit: Decimal
    profit_margin: Decimal
    total_contracts: int
    total_sessions: int
    total_hours: Decimal
    avg_daily_revenue: Decimal
    avg_revenue_per_contract: Decimal
    revenue_growth_rate: Optional[Decimal] = None

class BranchAnalytics(BaseModel):
    branch_id: int
    branch_name: str
    revenue: Decimal
    expenses: Decimal
    net_profit: Decimal
    contracts_count: int
    sessions_count: int
    hours_count: Decimal
    avg_hourly_rate: Decimal
    revenue_contribution: Decimal
    profit_rank: Optional[int] = None
    temporal_evolution: Optional[List[dict]] = None  # تطور أداء الفرع زمنيًا

class FinancialAnalytics(BaseModel):
    total_income: Decimal
    total_expenses: Decimal
    daily_profit: List[dict]
    monthly_profit: List[dict]
    profitability_by_branch: List[dict]
    profitability_by_contract_type: List[dict]
    avg_operational_cost_per_hour: Decimal
    top_contracts: List[dict]
    contracts_with_deficit: List[dict]
    cash_flow_overview: dict

class ContractsIntelligence(BaseModel):
    contracts_by_type: List[dict]
    total_contracts_value: Decimal
    total_paid: Decimal
    total_remaining: Decimal
    collection_rate: Decimal
    avg_contract_value: Decimal
    shared_contracts: dict
    contracts_by_course: List[dict]
    contracts_by_source: List[dict]

class PaymentPerformance(BaseModel):
    contracts_by_payment_method: List[dict]
    revenue_by_payment_method: List[dict]
    discounts_applied: Decimal
    most_profitable_methods: List[dict]

class OperationalAnalytics(BaseModel):
    daily_sessions: List[dict]
    daily_hours: List[dict]
    avg_session_duration: Decimal
    internal_vs_external: dict
    revenue_from_sessions: Decimal
    sessions_per_contract: Decimal
    operational_activity_by_branch: List[dict]

class SalesOverview(BaseModel):
    total_sales: Decimal
    total_deals: int
    avg_deal_value: Decimal
    total_calls: int
    total_visits: int
    total_leads: int
    conversion_rate: Decimal
    leads_by_source: dict

class SalesPerformance(BaseModel):
    sales_by_branch: List[dict]
    deals_by_branch: List[dict]
    conversion_efficiency_by_branch: List[dict]
    branch_ranking: List[dict]
    sales_trends: List[dict]

class VisitsAnalytics(BaseModel):
    total_visits: int
    visits_by_branch: List[dict]
    visit_results: dict
    visit_effectiveness: dict

class UserGovernance(BaseModel):
    users_by_role: dict
    users_by_branch: List[dict]
    active_vs_inactive: dict
    approval_history: List[dict]

class StrategicDashboard(BaseModel):
    top_profitable_branches: List[dict]
    top_growing_branches: List[dict]
    most_effective_income_sources: List[dict]
    highest_impact_contracts: List[dict]
    financial_risk_indicators: List[dict]
    operational_improvement_opportunities: List[dict]

class DailyReportsDetails(BaseModel):
    total_calls: int
    total_hot_calls: int
    total_branch_leads: int
    total_online_leads: int
    total_visits: int
    total_net_amount: Decimal
    total_remaining_amount: Decimal
    total_discounted: Decimal = Decimal(0)  # إجمالي المخصوم بنسب

class PaymentMethodDetails(BaseModel):
    payment_method_id: int
    payment_method_name: str
    total_paid: Decimal
    total_discounted: Decimal
    total_net: Decimal
    transactions_count: int

class CourseDetails(BaseModel):
    course_id: int
    course_name: str
    branches_count: int
    total_value: Decimal
    contracts_count: int

class SalesStaffDetails(BaseModel):
    staff_id: int
    staff_name: str
    branch_id: int
    branch_name: str
    total_sales: Decimal
    total_deals: int
    total_calls: int
    total_visits: int
    total_leads: int
    contracts_count: int
    contracts_value: Decimal

class BranchComprehensiveStats(BaseModel):
    branch_id: int
    branch_name: str
    # الإحصائيات الإجمالية
    total_daily_reports: int
    total_monthly_contracts: int
    total_contracts_value: Decimal
    total_paid_amount: Decimal
    total_remaining_amount: Decimal
    total_net_amount: Decimal
    # إحصائيات التقارير اليومية
    daily_reports_stats: DailyReportsDetails
    # إحصائيات حسب طريقة الدفع
    payment_methods_stats: List[PaymentMethodDetails]
    # إحصائيات الموظفين
    sales_staff_stats: List[SalesStaffDetails]

class IncompletePaymentContract(BaseModel):
    contract_id: int
    contract_number: str
    student_name: str
    branch_name: str
    sales_staff_name: str
    total_amount: Decimal
    paid_amount: Decimal
    remaining_amount: Decimal
    net_amount: Decimal
    course_name: str
    registration_source: str
    created_at: str

class CourseRegistrationDetails(BaseModel):
    course_id: int
    course_name: str
    total_registrations: int
    total_value: Decimal
    paid_amount: Decimal
    remaining_amount: Decimal
    net_amount: Decimal
    branches_count: int
    contracts_by_branch: List[dict]

class ComprehensiveStatistics(BaseModel):
    executive_kpis: ExecutiveKPIs
    branch_analytics: List[BranchAnalytics]
    financial_analytics: FinancialAnalytics
    contracts_intelligence: ContractsIntelligence
    payment_performance: PaymentPerformance
    operational_analytics: OperationalAnalytics
    sales_overview: SalesOverview
    sales_performance: SalesPerformance
    visits_analytics: VisitsAnalytics
    user_governance: UserGovernance
    strategic_dashboard: StrategicDashboard
    # الإضافات الجديدة
    daily_reports_details: DailyReportsDetails
    payment_methods_details: List[PaymentMethodDetails]
    courses_details: List[CourseDetails]
    sales_staff_details: List[SalesStaffDetails]
    branches_comprehensive: List[BranchComprehensiveStats]
    total_unique_days: int  # عدد الأيام الفريدة على مستوى جميع الفروع
    incomplete_payment_contracts: List[IncompletePaymentContract]  # العقود التي مازالت تملك دفعة غير مكتملة
    course_registration_details: List[CourseRegistrationDetails]  # تفاصيل التسجيل في كل نوع كورس

@app.get("/statistics/comprehensive", response_model=ComprehensiveStatistics)
def get_comprehensive_statistics(
    branch_id: Optional[int] = None,
    sales_staff_id: Optional[int] = None,
    date_from: Optional[date] = None,
    date_to: Optional[date] = None,
    year: Optional[int] = None,
    month: Optional[int] = None,
    db: Session = Depends(get_db),
    user: OperationAccount = Depends(get_current_user),
):
    """
    إحصائيات شاملة لجميع المؤشرات المطلوبة
    """
    try:
        # تحديد الفترة الزمنية
        if year and month:
            date_from = date(year, month, 1)
            if month == 12:
                date_to = date(year + 1, 1, 1) - timedelta(days=1)
            else:
                date_to = date(year, month + 1, 1) - timedelta(days=1)
        elif year:
            date_from = date(year, 1, 1)
            date_to = date(year, 12, 31)
        elif not date_from:
            # افتراضي: آخر 30 يوم
            date_to = date.today()
            date_from = date_to - timedelta(days=30)
        if not date_to:
            date_to = date.today()
        
        # تطبيق قيود الصلاحيات
        if branch_id:
            assert_branch_access(user, branch_id)
        elif not user.is_super_admin and not user.is_backdoor:
            branch_id = user.branch_id
        
        # ========== 1. Executive KPIs ==========
        daily_reports_query = db.query(DailyReport)
        if branch_id:
            daily_reports_query = daily_reports_query.filter(DailyReport.branch_id == branch_id)
        elif not user.is_super_admin:
            daily_reports_query = daily_reports_query.filter(DailyReport.branch_id == user.branch_id)
        if date_from:
            daily_reports_query = daily_reports_query.filter(DailyReport.report_date >= date_from)
        if date_to:
            daily_reports_query = daily_reports_query.filter(DailyReport.report_date <= date_to)
        
        daily_reports = daily_reports_query.all()
        
        total_revenue = sum(Decimal(str(r.total_amount or 0)) for r in daily_reports)
        total_expenses = sum(Decimal(str(r.total_expenses or 0)) for r in daily_reports)
        net_profit = sum(Decimal(str(r.net_profit or 0)) for r in daily_reports)
        profit_margin = (net_profit / total_revenue * 100) if total_revenue > 0 else Decimal(0)
        total_sessions = sum(r.total_sessions or 0 for r in daily_reports)
        total_hours = sum(Decimal(str(r.total_hours or 0)) for r in daily_reports)
        
        # عدد العقود (استخدام contract_date إذا كان موجوداً، وإلا created_at)
        contracts_query = db.query(Contract)
        if sales_staff_id:
            contracts_query = contracts_query.filter(Contract.sales_staff_id == sales_staff_id)
        if branch_id:
            contracts_query = contracts_query.filter(Contract.branch_id == branch_id)
        elif not user.is_super_admin:
            contracts_query = contracts_query.filter(Contract.branch_id == user.branch_id)
        if date_from:
            # استخدام contract_date إذا كان موجوداً، وإلا created_at (مع تحويل created_at إلى date)
            contracts_query = contracts_query.filter(
                or_(
                    and_(Contract.contract_date.isnot(None), Contract.contract_date >= date_from),
                    and_(Contract.contract_date.is_(None), func.DATE(Contract.created_at) >= date_from)
                )
            )
        if date_to:
            # استخدام contract_date إذا كان موجوداً، وإلا created_at (مع تحويل created_at إلى date)
            contracts_query = contracts_query.filter(
                or_(
                    and_(Contract.contract_date.isnot(None), Contract.contract_date <= date_to),
                    and_(Contract.contract_date.is_(None), func.DATE(Contract.created_at) <= date_to)
                )
            )
        total_contracts = contracts_query.count()
        
        # متوسط الإيراد اليومي
        days_count = (date_to - date_from).days + 1 if date_from and date_to else 1
        avg_daily_revenue = total_revenue / Decimal(days_count) if days_count > 0 else Decimal(0)
        
        # متوسط الإيراد لكل عقد
        contracts_with_amount = contracts_query.all()
        total_contracts_value = sum(Decimal(str(c.total_amount or 0)) for c in contracts_with_amount)
        avg_revenue_per_contract = total_contracts_value / Decimal(total_contracts) if total_contracts > 0 else Decimal(0)
        
        # معدل النمو (مقارنة مع الفترة السابقة)
        revenue_growth_rate = None
        if date_from and date_to:
            period_days = (date_to - date_from).days
            prev_date_from = date_from - timedelta(days=period_days + 1)
            prev_date_to = date_from - timedelta(days=1)
            prev_reports_query = db.query(DailyReport)
            if branch_id:
                prev_reports_query = prev_reports_query.filter(DailyReport.branch_id == branch_id)
            elif not user.is_super_admin:
                prev_reports_query = prev_reports_query.filter(DailyReport.branch_id == user.branch_id)
            prev_reports_query = prev_reports_query.filter(
                DailyReport.report_date >= prev_date_from,
                DailyReport.report_date <= prev_date_to
            )
            prev_reports = prev_reports_query.all()
            prev_revenue = sum(Decimal(str(r.total_amount or 0)) for r in prev_reports)
            if prev_revenue > 0:
                revenue_growth_rate = ((total_revenue - prev_revenue) / prev_revenue) * 100
        
        executive_kpis = ExecutiveKPIs(
            total_revenue=total_revenue,
            total_expenses=total_expenses,
            net_profit=net_profit,
            profit_margin=profit_margin,
            total_contracts=total_contracts,
            total_sessions=total_sessions,
            total_hours=total_hours,
            avg_daily_revenue=avg_daily_revenue,
            avg_revenue_per_contract=avg_revenue_per_contract,
            revenue_growth_rate=revenue_growth_rate
        )
        
        # ========== 2. Branch Analytics ==========
        branches_query = db.query(Branch)
        if branch_id:
            branches_query = branches_query.filter(Branch.id == branch_id)
        elif not user.is_super_admin and not user.is_backdoor:
            # لمدير المبيعات: فقط فرعه
            branches_query = branches_query.filter(Branch.id == user.branch_id)
        branches_list = branches_query.all()
        
        branch_analytics_list = []
        for branch in branches_list:
            branch_reports = [r for r in daily_reports if r.branch_id == branch.id]
            branch_revenue = sum(Decimal(str(r.total_amount or 0)) for r in branch_reports)
            branch_expenses = sum(Decimal(str(r.total_expenses or 0)) for r in branch_reports)
            branch_profit = sum(Decimal(str(r.net_profit or 0)) for r in branch_reports)
            branch_sessions = sum(r.total_sessions or 0 for r in branch_reports)
            branch_hours = sum(Decimal(str(r.total_hours or 0)) for r in branch_reports)
            
            branch_contracts_query = db.query(Contract).filter(Contract.branch_id == branch.id)
            if sales_staff_id:
                branch_contracts_query = branch_contracts_query.filter(Contract.sales_staff_id == sales_staff_id)
            if date_from:
                # استخدام contract_date كأولوية، وإلا created_at
                branch_contracts_query = branch_contracts_query.filter(
                    or_(
                        and_(Contract.contract_date.isnot(None), Contract.contract_date >= date_from),
                        and_(Contract.contract_date.is_(None), func.DATE(Contract.created_at) >= date_from)
                    )
                )
            if date_to:
                # استخدام contract_date كأولوية، وإلا created_at
                branch_contracts_query = branch_contracts_query.filter(
                    or_(
                        and_(Contract.contract_date.isnot(None), Contract.contract_date <= date_to),
                        and_(Contract.contract_date.is_(None), func.DATE(Contract.created_at) <= date_to)
                    )
                )
            branch_contracts_count = branch_contracts_query.count()
            
            revenue_contribution = (branch_revenue / total_revenue * 100) if total_revenue > 0 else Decimal(0)
            
            # تطور أداء الفرع زمنيًا (صافي الربح والإيرادات عبر الزمن)
            temporal_evolution = []
            if date_from and date_to:
                current_date = date_from
                while current_date <= date_to:
                    day_reports = [r for r in branch_reports if r.report_date == current_date]
                    day_revenue = sum(Decimal(str(r.total_amount or 0)) for r in day_reports)
                    day_profit = sum(Decimal(str(r.net_profit or 0)) for r in day_reports)
                    temporal_evolution.append({
                        "date": current_date.isoformat(),
                        "revenue": float(day_revenue),
                        "profit": float(day_profit)
                    })
                    current_date += timedelta(days=1)
            
            branch_analytics_list.append(BranchAnalytics(
                branch_id=branch.id,
                branch_name=branch.name,
                revenue=branch_revenue,
                expenses=branch_expenses,
                net_profit=branch_profit,
                contracts_count=branch_contracts_count,
                sessions_count=branch_sessions,
                hours_count=branch_hours,
                avg_hourly_rate=branch.default_hourly_rate,
                revenue_contribution=revenue_contribution,
                temporal_evolution=temporal_evolution if temporal_evolution else None
            ))
        
        # ترتيب الفروع حسب الربح
        branch_analytics_list.sort(key=lambda x: x.net_profit, reverse=True)
        for idx, branch_analytics in enumerate(branch_analytics_list, 1):
            branch_analytics.profit_rank = idx
        
        # ========== 3. Financial Analytics ==========
        # صافي الربح اليومي/الشهري
        daily_profit = []
        monthly_profit = []
        
        if date_from and date_to:
            current_date = date_from
            while current_date <= date_to:
                day_reports = [r for r in daily_reports if r.report_date == current_date]
                day_profit = sum(Decimal(str(r.net_profit or 0)) for r in day_reports)
                daily_profit.append({
                    "date": current_date.isoformat(),
                    "profit": float(day_profit)
                })
                current_date += timedelta(days=1)
            
            # تجميع شهري
            monthly_dict = {}
            for r in daily_reports:
                month_key = f"{r.report_date.year}-{r.report_date.month:02d}"
                if month_key not in monthly_dict:
                    monthly_dict[month_key] = Decimal(0)
                monthly_dict[month_key] += Decimal(str(r.net_profit or 0))
            
            monthly_profit = [{"month": k, "profit": float(v)} for k, v in sorted(monthly_dict.items())]
        
        # الربحية حسب نوع العقد
        profitability_by_contract_type = []
        contract_types = contracts_query.with_entities(Contract.contract_type).distinct().all()
        for (contract_type,) in contract_types:
            type_contracts = contracts_query.filter(Contract.contract_type == contract_type).all()
            type_value = sum(Decimal(str(c.total_amount or 0)) for c in type_contracts)
            profitability_by_contract_type.append({
                "contract_type": contract_type,
                "total_value": float(type_value),
                "count": len(type_contracts)
            })
        
        # متوسط تكلفة الساعة
        avg_operational_cost = total_expenses / total_hours if total_hours > 0 else Decimal(0)
        
        # العقود الأعلى قيمة
        top_contracts = contracts_query.order_by(Contract.total_amount.desc()).limit(10).all()
        top_contracts_list = [{
            "id": c.id,
            "contract_number": c.contract_number,
            "total_amount": float(c.total_amount or 0),
            "branch_id": c.branch_id,
            "student_name": c.student_name
        } for c in top_contracts]
        
        # العقود ذات العجز
        deficit_contracts = contracts_query.filter(Contract.remaining_amount > 0).all()
        deficit_contracts_list = [{
            "id": c.id,
            "contract_number": c.contract_number,
            "remaining_amount": float(c.remaining_amount or 0),
            "branch_id": c.branch_id,
            "student_name": c.student_name
        } for c in deficit_contracts]
        
        # التدفقات النقدية - استخدام ContractPayment
        payments_query = db.query(ContractPayment).join(Contract)
        if sales_staff_id:
            payments_query = payments_query.filter(Contract.sales_staff_id == sales_staff_id)
        if branch_id:
            payments_query = payments_query.filter(Contract.branch_id == branch_id)
        elif not user.is_super_admin and not user.is_backdoor:
            # لمدير المبيعات: فقط دفعات فرعه
            payments_query = payments_query.filter(Contract.branch_id == user.branch_id)
        if date_from:
            # استخدام contract_date كأولوية، وإلا created_at
            payments_query = payments_query.filter(
                or_(
                    and_(Contract.contract_date.isnot(None), Contract.contract_date >= date_from),
                    and_(Contract.contract_date.is_(None), func.DATE(Contract.created_at) >= date_from)
                )
            )
        if date_to:
            # استخدام contract_date كأولوية، وإلا created_at
            payments_query = payments_query.filter(
                or_(
                    and_(Contract.contract_date.isnot(None), Contract.contract_date <= date_to),
                    and_(Contract.contract_date.is_(None), func.DATE(Contract.created_at) <= date_to)
                )
            )
        all_payments = payments_query.all()
        total_paid = sum(Decimal(str(cp.payment_amount or 0)) for cp in all_payments)
        cash_flow_overview = {
            "total_collected": float(total_paid),
            "total_expenses": float(total_expenses),
            "net_cash_flow": float(total_paid - total_expenses)
        }
        
        financial_analytics = FinancialAnalytics(
            total_income=total_revenue,
            total_expenses=total_expenses,
            daily_profit=daily_profit,
            monthly_profit=monthly_profit,
            profitability_by_branch=[{
                "branch_id": ba.branch_id,
                "branch_name": ba.branch_name,
                "net_profit": float(ba.net_profit)
            } for ba in branch_analytics_list],
            profitability_by_contract_type=profitability_by_contract_type,
            avg_operational_cost_per_hour=avg_operational_cost,
            top_contracts=top_contracts_list,
            contracts_with_deficit=deficit_contracts_list,
            cash_flow_overview=cash_flow_overview
        )
        
        # ========== 4. Contracts Intelligence ==========
        # العقود حسب النوع
        contracts_by_type = []
        for (contract_type,) in contract_types:
            count = contracts_query.filter(Contract.contract_type == contract_type).count()
            contracts_by_type.append({"type": contract_type, "count": count})
        
        # المبالغ المدفوعة والمتبقية - استخدام ContractPayment
        total_paid_amount = sum(Decimal(str(cp.payment_amount or 0)) for cp in all_payments)
        total_remaining_amount = sum(Decimal(str(c.remaining_amount or 0)) for c in contracts_with_amount)
        collection_rate = (total_paid_amount / total_contracts_value * 100) if total_contracts_value > 0 else Decimal(0)
        
        # العقود المشتركة
        shared_contracts_query = contracts_query.filter(Contract.shared_branch_id.isnot(None))
        shared_contracts_count = shared_contracts_query.count()
        shared_amount = sum(Decimal(str(c.shared_amount or 0)) for c in shared_contracts_query.all())
        
        # العقود حسب الكورس
        contracts_by_course = []
        courses = db.query(Course).all()
        for course in courses:
            count = contracts_query.filter(Contract.course_id == course.id).count()
            if count > 0:
                contracts_by_course.append({
                    "course_id": course.id,
                    "course_name": course.name,
                    "count": count
                })
        
        # العقود حسب مصدر التسجيل
        contracts_by_source = []
        sources = contracts_query.with_entities(Contract.registration_source).distinct().filter(Contract.registration_source.isnot(None)).all()
        for (source,) in sources:
            count = contracts_query.filter(Contract.registration_source == source).count()
            contracts_by_source.append({"source": source, "count": count})
        
        contracts_intelligence = ContractsIntelligence(
            contracts_by_type=contracts_by_type,
            total_contracts_value=total_contracts_value,
            total_paid=total_paid_amount,
            total_remaining=total_remaining_amount,
            collection_rate=collection_rate,
            avg_contract_value=avg_revenue_per_contract,
            shared_contracts={"count": shared_contracts_count, "total_amount": float(shared_amount)},
            contracts_by_course=contracts_by_course,
            contracts_by_source=contracts_by_source
        )
        
        # ========== 5. Payment Performance ==========
        payment_methods = db.query(PaymentMethod).all()
        contracts_by_payment_method = []
        revenue_by_payment_method = []
        all_payment_contracts = []  # جمع جميع payment_contracts لحساب الخصومات
        
        for pm in payment_methods:
            # استخدام contract_payments للعقود المتعددة الدفعات
            payment_contracts_query = db.query(ContractPayment).filter(ContractPayment.payment_method_id == pm.id)
            payment_contracts_query = payment_contracts_query.join(Contract)
            if sales_staff_id:
                payment_contracts_query = payment_contracts_query.filter(Contract.sales_staff_id == sales_staff_id)
            if branch_id:
                payment_contracts_query = payment_contracts_query.filter(Contract.branch_id == branch_id)
            elif not user.is_super_admin:
                payment_contracts_query = payment_contracts_query.filter(Contract.branch_id == user.branch_id)
            if date_from:
                # استخدام contract_date كأولوية، وإلا created_at
                payment_contracts_query = payment_contracts_query.filter(
                    or_(
                        and_(Contract.contract_date.isnot(None), Contract.contract_date >= date_from),
                        and_(Contract.contract_date.is_(None), func.DATE(Contract.created_at) >= date_from)
                    )
                )
            if date_to:
                # استخدام contract_date كأولوية، وإلا created_at
                payment_contracts_query = payment_contracts_query.filter(
                    or_(
                        and_(Contract.contract_date.isnot(None), Contract.contract_date <= date_to),
                        and_(Contract.contract_date.is_(None), func.DATE(Contract.created_at) <= date_to)
                    )
                )
            
            payment_contracts = payment_contracts_query.all()
            all_payment_contracts.extend(payment_contracts)  # جمع للخصومات
            
            count = len(set(cp.contract_id for cp in payment_contracts))
            revenue = sum(Decimal(str(cp.payment_amount or 0)) for cp in payment_contracts)
            
            contracts_by_payment_method.append({
                "payment_method_id": pm.id,
                "payment_method_name": pm.name,
                "count": count
            })
            revenue_by_payment_method.append({
                "payment_method_id": pm.id,
                "payment_method_name": pm.name,
                "revenue": float(revenue)
            })
        
        # الخصومات المطبقة
        total_discounts = Decimal(0)
        for cp in all_payment_contracts:
            if cp.payment_method and cp.payment_method.discount_percentage:
                discount = Decimal(str(cp.payment_amount or 0)) * Decimal(str(cp.payment_method.discount_percentage))
                total_discounts += discount
        
        payment_performance = PaymentPerformance(
            contracts_by_payment_method=contracts_by_payment_method,
            revenue_by_payment_method=revenue_by_payment_method,
            discounts_applied=total_discounts,
            most_profitable_methods=sorted(revenue_by_payment_method, key=lambda x: x["revenue"], reverse=True)[:5]
        )
        
        # ========== 6. Operational Analytics ==========
        # الجلسات اليومية والساعات
        daily_sessions = []
        daily_hours_list = []
        if date_from and date_to:
            current_date = date_from
            while current_date <= date_to:
                day_reports = [r for r in daily_reports if r.report_date == current_date]
                day_sessions = sum(r.total_sessions or 0 for r in day_reports)
                day_hours = sum(Decimal(str(r.total_hours or 0)) for r in day_reports)
                daily_sessions.append({"date": current_date.isoformat(), "sessions": day_sessions})
                daily_hours_list.append({"date": current_date.isoformat(), "hours": float(day_hours)})
                current_date += timedelta(days=1)
        
        # متوسط مدة الجلسة
        sessions_query = db.query(SessionRecord)
        if branch_id:
            sessions_query = sessions_query.filter(SessionRecord.branch_id == branch_id)
        elif not user.is_super_admin:
            sessions_query = sessions_query.filter(SessionRecord.branch_id == user.branch_id)
        if date_from:
            sessions_query = sessions_query.filter(SessionRecord.session_date >= date_from)
        if date_to:
            sessions_query = sessions_query.filter(SessionRecord.session_date <= date_to)
        
        all_sessions = sessions_query.all()
        total_session_duration = sum(Decimal(str(s.duration_hours or 0)) for s in all_sessions)
        avg_session_duration = total_session_duration / Decimal(len(all_sessions)) if len(all_sessions) > 0 else Decimal(0)
        
        # توزيع داخلي/خارجي
        total_internal = sum(r.internal_sessions or 0 for r in daily_reports)
        total_external = sum(r.external_sessions or 0 for r in daily_reports)
        
        # الإيراد من الجلسات
        revenue_from_sessions = sum(Decimal(str(s.calculated_amount or 0)) for s in all_sessions)
        
        # الجلسات لكل عقد
        sessions_per_contract = Decimal(len(all_sessions)) / Decimal(total_contracts) if total_contracts > 0 else Decimal(0)
        
        # النشاط التشغيلي لكل فرع
        operational_activity = []
        for branch in branches_list:
            branch_hours = sum(Decimal(str(r.total_hours or 0)) for r in daily_reports if r.branch_id == branch.id)
            operational_activity.append({
                "branch_id": branch.id,
                "branch_name": branch.name,
                "total_hours": float(branch_hours)
            })
        
        operational_analytics = OperationalAnalytics(
            daily_sessions=daily_sessions,
            daily_hours=daily_hours_list,
            avg_session_duration=avg_session_duration,
            internal_vs_external={"internal": total_internal, "external": total_external},
            revenue_from_sessions=revenue_from_sessions,
            sessions_per_contract=sessions_per_contract,
            operational_activity_by_branch=operational_activity
        )
        
        # ========== 7. Sales Overview ==========
        sales_reports_query = db.query(DailySalesReport)
        if sales_staff_id:
            sales_reports_query = sales_reports_query.filter(DailySalesReport.sales_staff_id == sales_staff_id)
        if branch_id:
            sales_reports_query = sales_reports_query.filter(DailySalesReport.branch_id == branch_id)
        elif not user.is_super_admin:
            sales_reports_query = sales_reports_query.filter(DailySalesReport.branch_id == user.branch_id)
        if date_from:
            sales_reports_query = sales_reports_query.filter(DailySalesReport.report_date >= date_from)
        if date_to:
            sales_reports_query = sales_reports_query.filter(DailySalesReport.report_date <= date_to)
        
        sales_reports = sales_reports_query.all()
        
        total_sales = sum(Decimal(str(r.sales_amount or 0)) for r in sales_reports)
        total_deals = sum(r.number_of_deals or 0 for r in sales_reports)
        avg_deal_value = total_sales / Decimal(total_deals) if total_deals > 0 else Decimal(0)
        total_calls = sum(r.daily_calls or 0 for r in sales_reports)
        total_visits = sum(r.number_of_visits or 0 for r in sales_reports)
        total_leads = sum((r.branch_leads or 0) + (r.online_leads or 0) + (r.extra_leads or 0) for r in sales_reports)
        conversion_rate = (Decimal(total_contracts) / Decimal(total_leads) * 100) if total_leads > 0 else Decimal(0)
        
        branch_leads_total = sum(r.branch_leads or 0 for r in sales_reports)
        online_leads_total = sum(r.online_leads or 0 for r in sales_reports)
        extra_leads_total = sum(r.extra_leads or 0 for r in sales_reports)
        
        sales_overview = SalesOverview(
            total_sales=total_sales,
            total_deals=total_deals,
            avg_deal_value=avg_deal_value,
            total_calls=total_calls,
            total_visits=total_visits,
            total_leads=total_leads,
            conversion_rate=conversion_rate,
            leads_by_source={
                "branch": branch_leads_total,
                "online": online_leads_total,
                "extra": extra_leads_total
            }
        )
        
        # ========== 8. Sales Performance ==========
        sales_by_branch = []
        deals_by_branch = []
        conversion_efficiency_by_branch = []
        for branch in branches_list:
            branch_sales_reports = [r for r in sales_reports if r.branch_id == branch.id]
            branch_sales = sum(Decimal(str(r.sales_amount or 0)) for r in branch_sales_reports)
            branch_deals = sum(r.number_of_deals or 0 for r in branch_sales_reports)
            branch_leads = sum((r.branch_leads or 0) + (r.online_leads or 0) + (r.extra_leads or 0) for r in branch_sales_reports)
            branch_contracts = contracts_query.filter(Contract.branch_id == branch.id).count()
            conversion_efficiency = (Decimal(branch_contracts) / Decimal(branch_leads) * 100) if branch_leads > 0 else Decimal(0)
            
            sales_by_branch.append({
                "branch_id": branch.id,
                "branch_name": branch.name,
                "sales": float(branch_sales)
            })
            deals_by_branch.append({
                "branch_id": branch.id,
                "branch_name": branch.name,
                "deals": branch_deals
            })
            conversion_efficiency_by_branch.append({
                "branch_id": branch.id,
                "branch_name": branch.name,
                "efficiency": float(conversion_efficiency)
            })
        
        branch_ranking = sorted(sales_by_branch, key=lambda x: x["sales"], reverse=True)
        
        # اتجاهات المبيعات
        sales_trends = []
        if date_from and date_to:
            current_date = date_from
            while current_date <= date_to:
                day_sales_reports = [r for r in sales_reports if r.report_date == current_date]
                day_sales = sum(Decimal(str(r.sales_amount or 0)) for r in day_sales_reports)
                sales_trends.append({
                    "date": current_date.isoformat(),
                    "sales": float(day_sales)
                })
                current_date += timedelta(days=1)
        
        sales_performance = SalesPerformance(
            sales_by_branch=sales_by_branch,
            deals_by_branch=deals_by_branch,
            conversion_efficiency_by_branch=conversion_efficiency_by_branch,
            branch_ranking=branch_ranking,
            sales_trends=sales_trends
        )
        
        # ========== 9. Visits Analytics ==========
        # استخدام subquery لتجنب JOINs مكررة
        visits_query = db.query(SalesVisit).join(DailySalesReport, SalesVisit.daily_sales_report_id == DailySalesReport.id)
        
        if sales_staff_id:
            visits_query = visits_query.filter(DailySalesReport.sales_staff_id == sales_staff_id)
        if branch_id:
            visits_query = visits_query.filter(DailySalesReport.branch_id == branch_id)
        elif not user.is_super_admin:
            visits_query = visits_query.filter(DailySalesReport.branch_id == user.branch_id)
        if date_from:
            visits_query = visits_query.filter(DailySalesReport.report_date >= date_from)
        if date_to:
            visits_query = visits_query.filter(DailySalesReport.report_date <= date_to)
        
        total_visits_count = visits_query.count()
        
        visits_by_branch_list = []
        for branch in branches_list:
            # استخدام نفس query base مع filter إضافي للفرع
            branch_visits_query = db.query(SalesVisit).join(
                DailySalesReport, SalesVisit.daily_sales_report_id == DailySalesReport.id
            ).filter(DailySalesReport.branch_id == branch.id)
            if sales_staff_id:
                branch_visits_query = branch_visits_query.filter(DailySalesReport.sales_staff_id == sales_staff_id)
            if date_from:
                branch_visits_query = branch_visits_query.filter(DailySalesReport.report_date >= date_from)
            if date_to:
                branch_visits_query = branch_visits_query.filter(DailySalesReport.report_date <= date_to)
            branch_visits = branch_visits_query.count()
            visits_by_branch_list.append({
                "branch_id": branch.id,
                "branch_name": branch.name,
                "visits": branch_visits
            })
        
        visits_analytics = VisitsAnalytics(
            total_visits=total_visits_count,
            visits_by_branch=visits_by_branch_list,
            visit_results={},  # يتطلب معالجة نصية
            visit_effectiveness={}  # يتطلب تحليل ارتباط
        )
        
        # ========== 10. User Governance ==========
        users_by_role = {
            "super_admin": db.query(OperationAccount).filter(OperationAccount.is_super_admin == True).count(),
            "sales_manager": db.query(OperationAccount).filter(OperationAccount.is_sales_manager == True).count(),
            "operation_manager": db.query(OperationAccount).filter(OperationAccount.is_operation_manager == True).count(),
            "branch_account": db.query(OperationAccount).filter(OperationAccount.is_branch_account == True).count()
        }
        
        users_by_branch_list = []
        for branch in branches_list:
            count = db.query(OperationAccount).filter(OperationAccount.branch_id == branch.id).count()
            users_by_branch_list.append({
                "branch_id": branch.id,
                "branch_name": branch.name,
                "users_count": count
            })
        
        active_users = db.query(OperationAccount).filter(OperationAccount.is_active == True).count()
        inactive_users = db.query(OperationAccount).filter(OperationAccount.is_active == False).count()
        
        approval_history = []
        for session in all_sessions[:50]:  # آخر 50 جلسة
            approver = db.query(OperationAccount).filter(OperationAccount.id == session.approved_by).first()
            if approver:
                approval_history.append({
                    "session_id": session.id,
                    "approved_by": approver.username,
                    "approved_at": session.created_at.isoformat() if session.created_at else None
                })
        
        user_governance = UserGovernance(
            users_by_role=users_by_role,
            users_by_branch=users_by_branch_list,
            active_vs_inactive={"active": active_users, "inactive": inactive_users},
            approval_history=approval_history
        )
        
        # ========== 11. Strategic Dashboard ==========
        top_profitable_branches = sorted(branch_analytics_list, key=lambda x: x.net_profit, reverse=True)[:5]
        top_profitable = [{
            "branch_id": ba.branch_id,
            "branch_name": ba.branch_name,
            "net_profit": float(ba.net_profit)
        } for ba in top_profitable_branches]
        
        # الفروع الأعلى نمواً (مقارنة الفترة الحالية بالسابقة)
        top_growing = []
        for branch in branches_list:
            current_profit = sum(Decimal(str(r.net_profit or 0)) for r in daily_reports if r.branch_id == branch.id)
            if date_from and date_to:
                prev_date_from = date_from - timedelta(days=(date_to - date_from).days + 1)
                prev_date_to = date_from - timedelta(days=1)
                prev_reports_query = db.query(DailyReport).filter(DailyReport.branch_id == branch.id)
                prev_reports_query = prev_reports_query.filter(
                    DailyReport.report_date >= prev_date_from,
                    DailyReport.report_date <= prev_date_to
                )
                prev_reports = prev_reports_query.all()
                prev_profit = sum(Decimal(str(r.net_profit or 0)) for r in prev_reports)
                if prev_profit > 0:
                    growth_rate = ((current_profit - prev_profit) / prev_profit) * 100
                    top_growing.append({
                        "branch_id": branch.id,
                        "branch_name": branch.name,
                        "growth_rate": float(growth_rate)
                    })
        
        top_growing = sorted(top_growing, key=lambda x: x["growth_rate"], reverse=True)[:5]
        
        # مصادر الدخل الأكثر فعالية
        most_effective_sources = sorted(contracts_by_source, key=lambda x: x["count"], reverse=True)[:5]
        
        # العقود الأعلى تأثيراً
        highest_impact = top_contracts_list[:5]
        
        # مؤشرات الخطر المالي
        financial_risks = []
        for contract in deficit_contracts_list[:10]:
            financial_risks.append({
                "contract_id": contract["id"],
                "contract_number": contract["contract_number"],
                "remaining_amount": contract["remaining_amount"],
                "risk_level": "high" if contract["remaining_amount"] > 10000 else "medium"
            })
        
        # فرص التحسين التشغيلي
        improvement_opportunities = []
        for branch in branches_list:
            branch_hours = sum(Decimal(str(r.total_hours or 0)) for r in daily_reports if r.branch_id == branch.id)
            branch_sessions = sum(r.total_sessions or 0 for r in daily_reports if r.branch_id == branch.id)
            if branch_sessions > 0:
                avg_hours_per_session = branch_hours / Decimal(branch_sessions)
                improvement_opportunities.append({
                    "branch_id": branch.id,
                    "branch_name": branch.name,
                    "avg_hours_per_session": float(avg_hours_per_session),
                    "suggestion": "تحسين كفاءة الجلسات" if avg_hours_per_session > 2 else "مستوى جيد"
                })
        
        strategic_dashboard = StrategicDashboard(
            top_profitable_branches=top_profitable,
            top_growing_branches=top_growing,
            most_effective_income_sources=most_effective_sources,
            highest_impact_contracts=highest_impact,
            financial_risk_indicators=financial_risks,
            operational_improvement_opportunities=improvement_opportunities
        )
        
        # ========== إضافات جديدة ==========
        
        # 1. تفاصيل التقارير اليومية
        total_calls_from_reports = sum(r.daily_calls or 0 for r in sales_reports)
        total_hot_calls_from_reports = sum(r.hot_calls or 0 for r in sales_reports)
        total_branch_leads_from_reports = sum(r.branch_leads or 0 for r in sales_reports)
        total_online_leads_from_reports = sum(r.online_leads or 0 for r in sales_reports)
        total_visits_from_reports = sum(r.number_of_visits or 0 for r in sales_reports)
        
        # حساب إجمالي المخصوم من جميع طرق الدفع
        total_discounted_amount = Decimal(0)
        for pm in payment_methods:
            pm_payments = [cp for cp in all_payments if cp.payment_method_id == pm.id]
            pm_total_paid = sum(Decimal(str(cp.payment_amount or 0)) for cp in pm_payments)
            pm_discount_percentage = Decimal(str(pm.discount_percentage or 0)) / 100 if pm.discount_percentage else Decimal(0)
            pm_total_discounted = pm_total_paid * pm_discount_percentage
            total_discounted_amount += pm_total_discounted
        
        daily_reports_details = DailyReportsDetails(
            total_calls=total_calls_from_reports,
            total_hot_calls=total_hot_calls_from_reports,
            total_branch_leads=total_branch_leads_from_reports,
            total_online_leads=total_online_leads_from_reports,
            total_visits=total_visits_from_reports,
            total_net_amount=sum(Decimal(str(c.net_amount or 0)) for c in contracts_with_amount),
            total_remaining_amount=total_remaining_amount,
            total_discounted=total_discounted_amount
        )
        
        # 2. تفاصيل طرق الدفع (المدفوع والمخصوم)
        payment_methods_details_list = []
        for pm in payment_methods:
            pm_payments = [cp for cp in all_payments if cp.payment_method_id == pm.id]
            pm_total_paid = sum(Decimal(str(cp.payment_amount or 0)) for cp in pm_payments)
            pm_discount_percentage = Decimal(str(pm.discount_percentage or 0)) / 100 if pm.discount_percentage else Decimal(0)
            pm_total_discounted = pm_total_paid * pm_discount_percentage
            pm_total_net = sum(Decimal(str(cp.net_amount or 0)) for cp in pm_payments if cp.net_amount)
            
            payment_methods_details_list.append(PaymentMethodDetails(
                payment_method_id=pm.id,
                payment_method_name=pm.name,
                total_paid=pm_total_paid,
                total_discounted=pm_total_discounted,
                total_net=pm_total_net,
                transactions_count=len(pm_payments)
            ))
        
        # 3. تفاصيل الكورسات (في كم فرع وكمية الفلوس)
        courses_details_list = []
        for course in courses:
            course_contracts = contracts_query.filter(Contract.course_id == course.id).all()
            # فقط عرض الكورسات التي لديها عقود في الفرع المحدد
            if len(course_contracts) == 0:
                continue
            # التأكد من أن جميع العقود من الفرع المصرح به (للمستخدمين غير super_admin)
            if not user.is_super_admin and not user.is_backdoor:
                course_contracts = [c for c in course_contracts if c.branch_id == user.branch_id]
                if len(course_contracts) == 0:
                    continue
            course_branches = set(c.branch_id for c in course_contracts if c.branch_id)
            course_total_value = sum(Decimal(str(c.total_amount or 0)) for c in course_contracts)
            
            courses_details_list.append(CourseDetails(
                course_id=course.id,
                course_name=course.name,
                branches_count=len(course_branches),
                total_value=course_total_value,
                contracts_count=len(course_contracts)
            ))
        
        # 4. تفاصيل موظفي المبيعات
        sales_staff_details_list = []
        sales_staff_members = db.query(SalesStaff)
        if sales_staff_id:
            sales_staff_members = sales_staff_members.filter(SalesStaff.id == sales_staff_id)
        elif branch_id:
            sales_staff_members = sales_staff_members.filter(SalesStaff.branch_id == branch_id)
        elif not user.is_super_admin:
            sales_staff_members = sales_staff_members.filter(SalesStaff.branch_id == user.branch_id)
        sales_staff_members = sales_staff_members.all()
        
        for staff in sales_staff_members:
            staff_sales_reports = [r for r in sales_reports if r.sales_staff_id == staff.id]
            staff_total_sales = sum(Decimal(str(r.sales_amount or 0)) for r in staff_sales_reports)
            staff_total_deals = sum(r.number_of_deals or 0 for r in staff_sales_reports)
            staff_total_calls = sum(r.daily_calls or 0 for r in staff_sales_reports)
            staff_total_visits = sum(r.number_of_visits or 0 for r in staff_sales_reports)
            staff_total_leads = sum((r.branch_leads or 0) + (r.online_leads or 0) + (r.extra_leads or 0) for r in staff_sales_reports)
            
            staff_contracts = contracts_query.filter(Contract.sales_staff_id == staff.id).all()
            staff_contracts_count = len(staff_contracts)
            staff_contracts_value = sum(Decimal(str(c.total_amount or 0)) for c in staff_contracts)
            
            # كم مرة مذكور اسمه في التقارير اليومية
            staff_reports_count = len(staff_sales_reports)
            
            # الصافي لكل موظف (من عقوده)
            staff_net_amount = sum(Decimal(str(c.net_amount or 0)) for c in staff_contracts)
            
            staff_branch = db.query(Branch).filter(Branch.id == staff.branch_id).first()
            
            sales_staff_details_list.append(SalesStaffDetails(
                staff_id=staff.id,
                staff_name=staff.name,
                branch_id=staff.branch_id,
                branch_name=staff_branch.name if staff_branch else f"فرع {staff.branch_id}",
                total_sales=staff_total_sales,
                total_deals=staff_total_deals,
                total_calls=staff_total_calls,
                total_visits=staff_total_visits,
                total_leads=staff_total_leads,
                contracts_count=staff_contracts_count,
                contracts_value=staff_contracts_value,
                reports_count=staff_reports_count,
                total_net_amount=staff_net_amount
            ))
        
        # 5. إحصائيات شاملة لكل فرع
        # حساب الأيام الفريدة على مستوى جميع الفروع أولاً
        all_unique_dates = set()
        for report in sales_reports:
            if report.report_date:
                all_unique_dates.add(report.report_date)
        total_unique_days = len(all_unique_dates)
        
        branches_comprehensive_list = []
        for branch in branches_list:
            branch_daily_reports = [r for r in daily_reports if r.branch_id == branch.id]
            branch_sales_reports = [r for r in sales_reports if r.branch_id == branch.id]
            # جلب عقود الفرع مباشرة من قاعدة البيانات بدون استخدام contracts_query المحدود
            branch_contracts_query = db.query(Contract).filter(Contract.branch_id == branch.id)
            if sales_staff_id:
                branch_contracts_query = branch_contracts_query.filter(Contract.sales_staff_id == sales_staff_id)
            if date_from:
                # استخدام contract_date كأولوية، وإلا created_at
                branch_contracts_query = branch_contracts_query.filter(
                    or_(
                        and_(Contract.contract_date.isnot(None), Contract.contract_date >= date_from),
                        and_(Contract.contract_date.is_(None), func.DATE(Contract.created_at) >= date_from)
                    )
                )
            if date_to:
                # استخدام contract_date كأولوية، وإلا created_at
                branch_contracts_query = branch_contracts_query.filter(
                    or_(
                        and_(Contract.contract_date.isnot(None), Contract.contract_date <= date_to),
                        and_(Contract.contract_date.is_(None), func.DATE(Contract.created_at) <= date_to)
                    )
                )
            branch_contracts = branch_contracts_query.all()
            
            # الإحصائيات الإجمالية
            # حساب عدد الأيام الفريدة التي تحتوي على تقارير يومية (ليس عدد التقارير)
            unique_dates = set()
            for report in branch_sales_reports:
                if report.report_date:
                    unique_dates.add(report.report_date)
            branch_total_daily_reports = len(unique_dates)
            branch_monthly_contracts = len([c for c in branch_contracts if date_from and date_to and 
                                            datetime.combine(date_from, datetime.min.time()) <= c.created_at <= datetime.combine(date_to, datetime.max.time())])
            branch_total_contracts_value = sum(Decimal(str(c.total_amount or 0)) for c in branch_contracts)
            # الحصول على payments للفرع
            branch_contract_ids = [c.id for c in branch_contracts]
            branch_payments = [cp for cp in all_payments if cp.contract_id in branch_contract_ids]
            branch_total_paid = sum(Decimal(str(cp.payment_amount or 0)) for cp in branch_payments)
            branch_total_remaining = sum(Decimal(str(c.remaining_amount or 0)) for c in branch_contracts)
            branch_total_net = sum(Decimal(str(c.net_amount or 0)) for c in branch_contracts)
            
            # إحصائيات التقارير اليومية
            # حساب المخصوم للفرع
            branch_discounted = Decimal(0)
            for pm in payment_methods:
                branch_pm_payments = [cp for cp in branch_payments if cp.payment_method_id == pm.id]
                branch_pm_total_paid = sum(Decimal(str(cp.payment_amount or 0)) for cp in branch_pm_payments)
                branch_pm_discount = branch_pm_total_paid * (Decimal(str(pm.discount_percentage or 0)) / 100)
                branch_discounted += branch_pm_discount
            
            branch_daily_stats = DailyReportsDetails(
                total_calls=sum(r.daily_calls or 0 for r in branch_sales_reports),
                total_hot_calls=sum(r.hot_calls or 0 for r in branch_sales_reports),
                total_branch_leads=sum(r.branch_leads or 0 for r in branch_sales_reports),
                total_online_leads=sum(r.online_leads or 0 for r in branch_sales_reports),
                total_visits=sum(r.number_of_visits or 0 for r in branch_sales_reports),
                total_net_amount=branch_total_net,
                total_remaining_amount=branch_total_remaining,
                total_discounted=branch_discounted
            )
            
            # إحصائيات حسب طريقة الدفع للفرع
            branch_payment_methods_stats = []
            for pm in payment_methods:
                branch_pm_payments = [cp for cp in branch_payments if cp.payment_method_id == pm.id]
                branch_pm_total_paid = sum(Decimal(str(cp.payment_amount or 0)) for cp in branch_pm_payments)
                branch_pm_discount = branch_pm_total_paid * (Decimal(str(pm.discount_percentage or 0)) / 100)
                branch_pm_net = sum(Decimal(str(cp.net_amount or 0)) for cp in branch_pm_payments if cp.net_amount)
                
                branch_payment_methods_stats.append(PaymentMethodDetails(
                    payment_method_id=pm.id,
                    payment_method_name=pm.name,
                    total_paid=branch_pm_total_paid,
                    total_discounted=branch_pm_discount,
                    total_net=branch_pm_net,
                    transactions_count=len(branch_pm_payments)
                ))
            
            # إحصائيات الموظفين في الفرع
            branch_sales_staff = [s for s in sales_staff_details_list if s.branch_id == branch.id]
            
            branches_comprehensive_list.append(BranchComprehensiveStats(
                branch_id=branch.id,
                branch_name=branch.name,
                total_daily_reports=branch_total_daily_reports,
                total_monthly_contracts=branch_monthly_contracts,
                total_contracts_value=branch_total_contracts_value,
                total_paid_amount=branch_total_paid,
                total_remaining_amount=branch_total_remaining,
                total_net_amount=branch_total_net,
                daily_reports_stats=branch_daily_stats,
                payment_methods_stats=branch_payment_methods_stats,
                sales_staff_stats=branch_sales_staff
            ))
        
        # 6. العقود التي مازالت تملك دفعة غير مكتملة
        incomplete_payment_contracts_list = []
        incomplete_contracts = contracts_query.filter(Contract.remaining_amount > 0).all()
        for contract in incomplete_contracts:
            contract_payments = [cp for cp in all_payments if cp.contract_id == contract.id]
            contract_paid = sum(Decimal(str(cp.payment_amount or 0)) for cp in contract_payments)
            
            contract_branch = db.query(Branch).filter(Branch.id == contract.branch_id).first()
            contract_sales_staff = db.query(SalesStaff).filter(SalesStaff.id == contract.sales_staff_id).first() if contract.sales_staff_id else None
            contract_course = db.query(Course).filter(Course.id == contract.course_id).first() if contract.course_id else None
            
            incomplete_payment_contracts_list.append(IncompletePaymentContract(
                contract_id=contract.id,
                contract_number=contract.contract_number or f"عقد {contract.id}",
                student_name=contract.student_name or "",
                branch_name=contract_branch.name if contract_branch else f"فرع {contract.branch_id}",
                sales_staff_name=contract_sales_staff.name if contract_sales_staff else "غير محدد",
                total_amount=Decimal(str(contract.total_amount or 0)),
                paid_amount=contract_paid,
                remaining_amount=Decimal(str(contract.remaining_amount or 0)),
                net_amount=Decimal(str(contract.net_amount or 0)),
                course_name=contract_course.name if contract_course else "غير محدد",
                registration_source=contract.registration_source or "غير محدد",
                created_at=(contract.contract_date.isoformat() if contract.contract_date else (contract.created_at.isoformat() if contract.created_at else ""))
            ))
        
        # 7. تفاصيل التسجيل في كل نوع كورس
        course_registration_details_list = []
        for course in courses:
            course_contracts = contracts_query.filter(Contract.course_id == course.id).all()
            # فقط عرض الكورسات التي لديها عقود في الفرع المحدد
            if len(course_contracts) == 0:
                continue
            # التأكد من أن جميع العقود من الفرع المصرح به (للمستخدمين غير super_admin)
            if not user.is_super_admin and not user.is_backdoor:
                course_contracts = [c for c in course_contracts if c.branch_id == user.branch_id]
                if len(course_contracts) == 0:
                    continue
            course_branches = set(c.branch_id for c in course_contracts if c.branch_id)
            
            course_total_value = sum(Decimal(str(c.total_amount or 0)) for c in course_contracts)
            course_contract_ids = [c.id for c in course_contracts]
            course_payments = [cp for cp in all_payments if cp.contract_id in course_contract_ids]
            course_paid = sum(Decimal(str(cp.payment_amount or 0)) for cp in course_payments)
            course_remaining = sum(Decimal(str(c.remaining_amount or 0)) for c in course_contracts)
            course_net = sum(Decimal(str(c.net_amount or 0)) for c in course_contracts)
            
            # تفاصيل حسب الفرع - فقط الفروع المصرح بها
            contracts_by_branch = []
            for branch_id in course_branches:
                # التأكد من أن الفرع مصرح به (للمستخدمين غير super_admin)
                if not user.is_super_admin and not user.is_backdoor:
                    if branch_id != user.branch_id:
                        continue  # تخطي الفروع الأخرى لمدير المبيعات
                branch_contracts = [c for c in course_contracts if c.branch_id == branch_id]
                branch = db.query(Branch).filter(Branch.id == branch_id).first()
                contracts_by_branch.append({
                    "branch_id": branch_id,
                    "branch_name": branch.name if branch else f"فرع {branch_id}",
                    "contracts_count": len(branch_contracts),
                    "total_value": float(sum(Decimal(str(c.total_amount or 0)) for c in branch_contracts))
                })
            
            course_registration_details_list.append(CourseRegistrationDetails(
                course_id=course.id,
                course_name=course.name,
                total_registrations=len(course_contracts),
                total_value=course_total_value,
                paid_amount=course_paid,
                remaining_amount=course_remaining,
                net_amount=course_net,
                branches_count=len(course_branches),
                contracts_by_branch=contracts_by_branch
            ))
        
        return ComprehensiveStatistics(
            executive_kpis=executive_kpis,
            branch_analytics=branch_analytics_list,
            financial_analytics=financial_analytics,
            contracts_intelligence=contracts_intelligence,
            payment_performance=payment_performance,
            operational_analytics=operational_analytics,
            sales_overview=sales_overview,
            sales_performance=sales_performance,
            visits_analytics=visits_analytics,
            user_governance=user_governance,
            strategic_dashboard=strategic_dashboard,
            daily_reports_details=daily_reports_details,
            payment_methods_details=payment_methods_details_list,
            courses_details=courses_details_list,
            sales_staff_details=sales_staff_details_list,
            branches_comprehensive=branches_comprehensive_list,
            total_unique_days=total_unique_days,
            incomplete_payment_contracts=incomplete_payment_contracts_list,
            course_registration_details=course_registration_details_list
        )
        
    except Exception as e:
        logger.error(f"Error in get_comprehensive_statistics: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"خطأ في جلب الإحصائيات: {str(e)}")


